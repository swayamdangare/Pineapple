package com.glasslauncher.app

import android.animation.LayoutTransition
import android.content.Context
import android.graphics.ColorFilter
import android.graphics.DashPathEffect
import android.graphics.PixelFormat
import android.view.ViewTreeObserver
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs
import android.content.pm.ApplicationInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

private val LETTERS: List<String> = ('A'..'Z').map { it.toString() } + "#"

private const val KIND_PLAIN = 0
private const val KIND_BUILTIN = 1
private const val KIND_CUSTOM = 2
private const val KIND_HIDDEN = 3
private const val KIND_NEW = 4

// Small icons drawn in code (no image files needed).
class IconView(context: Context, var kind: Int) : View(context) {
    companion object {
        const val SEARCH = 0
        const val GRID = 1
        const val LIST = 2
    }

    private val density = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = min(width, height) * 0.22f
        p.color = Color.WHITE
        when (kind) {
            SEARCH -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * density
                p.strokeCap = Paint.Cap.ROUND
                canvas.drawCircle(cx - s * 0.2f, cy - s * 0.2f, s * 0.8f, p)
                canvas.drawLine(cx + s * 0.4f, cy + s * 0.4f, cx + s * 1.05f, cy + s * 1.05f, p)
            }
            GRID -> {
                p.style = Paint.Style.FILL
                val g = s * 0.15f
                val r = s * 0.9f
                for (i in 0..1) {
                    for (j in 0..1) {
                        val l = cx - r - g + j * (r + 2 * g)
                        val t = cy - r - g + i * (r + 2 * g)
                        canvas.drawRoundRect(l, t, l + r, t + r, 3f * density, 3f * density, p)
                    }
                }
            }
            else -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.2f * density
                p.strokeCap = Paint.Cap.ROUND
                for (i in -1..1) {
                    canvas.drawLine(cx - s * 1.1f, cy + i * s * 0.8f, cx + s * 1.1f, cy + i * s * 0.8f, p)
                }
            }
        }
    }
}

// Dashed "+" tile used for adding a category.
class NewTileDrawable(private val density: Float) : Drawable() {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val plus = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = 1.5f * density
        stroke.color = Color.argb(120, 255, 255, 255)
        stroke.pathEffect = DashPathEffect(floatArrayOf(8f * density, 6f * density), 0f)
        plus.style = Paint.Style.STROKE
        plus.strokeWidth = 3f * density
        plus.strokeCap = Paint.Cap.ROUND
        plus.color = Color.argb(200, 255, 255, 255)
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val r = 28f * density
        val inset = stroke.strokeWidth
        canvas.drawRoundRect(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset, r, r, stroke)
        val cx = b.exactCenterX()
        val cy = b.exactCenterY()
        val s = 14f * density
        canvas.drawLine(cx - s, cy, cx + s, cy, plus)
        canvas.drawLine(cx, cy - s, cx, cy + s, plus)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

// Sorts apps into groups. Own names, simple rules; the user can override any app.
object Categorizer {
    val ORDER = listOf(
        "Social", "Media", "Games", "Productivity", "Education",
        "Shopping", "Travel", "Finance", "Tools", "Other"
    )

    private val rules: List<Pair<String, List<String>>> = listOf(
        "Games" to listOf("game", "ludo", "pubg", "bgmi", "freefire", "free fire", "clash", "minecraft", "roblox", "chess", "candy"),
        "Social" to listOf("whatsapp", "telegram", "instagram", "facebook", "twitter", "snapchat", "discord", "linkedin", "reddit", "signal", "messenger", "threads", "pinterest", "sharechat"),
        "Finance" to listOf("gpay", "phonepe", "paytm", "bank", "upi", "wallet", "cred", "zerodha", "groww", "finance", "pay", "money", "insurance"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "meesho", "blinkit", "zepto", "swiggy", "zomato", "bigbasket", "ajio", "nykaa", "shop", "jiomart", "instamart"),
        "Travel" to listOf("maps", "uber", "ola ", "rapido", "irctc", "makemytrip", "goibibo", "redbus", "travel", "flight", "train", "navigation"),
        "Education" to listOf("allen", "examgoal", "byju", "unacademy", "physicswallah", "learn", "study", "classroom", "duolingo", "khan", "exam", "course", "school", "neet", "vedantu"),
        "Media" to listOf("youtube", "spotify", "netflix", "music", "video", "player", "camera", "gallery", "photos", "gaana", "jiosaavn", "hotstar", "radio", "podcast", "audio", "movie", "vlc"),
        "Productivity" to listOf("docs", "sheets", "slides", "drive", "office", "word", "excel", "powerpoint", "notes", "keep", "calendar", "mail", "outlook", "scan", "pdf", "notion", "zoom", "meet", "teams", "adobe", "todo", "tasks", "chatgpt", "claude", "gemini", "assistant"),
        "Tools" to listOf("calculator", "clock", "settings", "files", "file manager", "compass", "weather", "recorder", "torch", "flashlight", "security", "cleaner", "system", "android", "play services", "wellbeing", "contacts", "phone", "dialer", "browser", "chrome", "vault", "launcher", "downloads", "update", "backup", "manager", "translate")
    )

    fun categoryOf(e: AppEntry, prefs: PrefsStore): String {
        val custom = prefs.categoryOverride(e.key)
        if (custom != null) return custom
        val byApi: String? = when (e.category) {
            ApplicationInfo.CATEGORY_GAME -> "Games"
            ApplicationInfo.CATEGORY_AUDIO -> "Media"
            ApplicationInfo.CATEGORY_VIDEO -> "Media"
            ApplicationInfo.CATEGORY_IMAGE -> "Media"
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_NEWS -> "Media"
            ApplicationInfo.CATEGORY_MAPS -> "Travel"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
            else -> null
        }
        if (byApi != null) return byApi
        val text = (e.label + " " + e.component.packageName).lowercase()
        for (rule in rules) {
            for (w in rule.second) {
                if (text.contains(w)) return rule.first
            }
        }
        return "Other"
    }
}

class DrawerView(
    context: Context,
    private val prefs: PrefsStore,
    private val host: Host
) : FrameLayout(context) {

    interface Host {
        fun launch(e: AppEntry)
        fun longPress(view: View, e: AppEntry, items: List<Pair<String, () -> Unit>>)
        fun showMenu(anchor: View, items: List<Pair<String, () -> Unit>>)
        fun addToHome(e: AppEntry)
        fun addToDock(e: AppEntry)
        fun appInfo(e: AppEntry)
        fun uninstall(e: AppEntry)
        fun hideApp(e: AppEntry)
        fun requestAuth(onSuccess: () -> Unit)
        fun prompt(title: String, initial: String, onOk: (String) -> Unit)
        fun toast(msg: String)
    }

    private class Tile(val title: String, val apps: List<AppEntry>, val preview: List<AppEntry>, val kind: Int = KIND_PLAIN)
    private class Row(val letter: String?, val app: AppEntry?)

    private val d = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d).toInt()

    private var apps: List<AppEntry> = emptyList()
    private var visibleApps: List<AppEntry> = emptyList()
    private var tiles: List<Tile> = emptyList()
    private var rows: List<Row> = emptyList()
    private var panelApps: List<AppEntry> = emptyList()
    private var query = ""
    private var gridMode = prefs.drawerGrid
    private var searching = false
    private var dragActive = false
    private var dragEntry: AppEntry? = null
    private var hoverView: View? = null
    private var hoverTarget = 0
    private var hoverTile: Tile? = null
    private var tileSide = dp(150)
    private var insetL = 0
    private var insetR = 0

    private val body = LinearLayout(context)
    private val topRow = LinearLayout(context)
    private val pill = LinearLayout(context)
    private val searchIcon = IconView(context, IconView.SEARCH)
    private val search = EditText(context)
    private val toggle = IconView(context, if (gridMode) IconView.LIST else IconView.GRID)
    private val cancel = TextView(context)
    private val content = FrameLayout(context)
    private val tilesGrid = GridView(context)
    private val listContainer = FrameLayout(context)
    private val listView = ListView(context)
    private val sidebar = LinearLayout(context)
    private val panel = FrameLayout(context)
    private val card = LinearLayout(context)
    private val panelTitle = TextView(context)
    private val panelGrid = GridView(context)
    private val dropBar = LinearLayout(context)

    private val tilesAdapter = TilesAdapter()
    private val letterAdapter = LetterAdapter()
    private val panelAdapter = AppGridAdapter { panelApps }

    init {
        setBackgroundColor(Color.argb(242, 16, 16, 24))
        isClickable = true
        visibility = View.GONE

        body.orientation = LinearLayout.VERTICAL
        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.gravity = Gravity.CENTER_VERTICAL
        val lt = LayoutTransition()
        lt.enableTransitionType(LayoutTransition.CHANGING)
        lt.setDuration(200)
        topRow.layoutTransition = lt

        // Search pill
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(14), 0, dp(14), 0)
        pill.background = GradientDrawable().apply {
            setColor(0x2EFFFFFF)
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), 0x1FFFFFFF)
        }
        pill.addView(searchIcon, LinearLayout.LayoutParams(dp(20), dp(20)))
        search.hint = "Search apps"
        search.setHintTextColor(Color.argb(150, 255, 255, 255))
        search.setTextColor(Color.WHITE)
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        search.isSingleLine = true
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.background = null
        search.setPadding(dp(10), 0, 0, 0)
        search.setOnEditorActionListener { _, _, _ ->
            hideKeyboard()
            true
        }
        search.setOnFocusChangeListener { _, has -> if (has) enterSearch() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = (s?.toString() ?: "").trim()
                buildRows()
                letterAdapter.notifyDataSetChanged()
                updateContent()
            }
        })
        pill.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        topRow.addView(pill, LinearLayout.LayoutParams(0, dp(44), 1f))

        // Grid / list switch
        toggle.background = GradientDrawable().apply {
            setColor(0x2EFFFFFF)
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), 0x1FFFFFFF)
        }
        toggle.setOnClickListener {
            gridMode = !gridMode
            prefs.drawerGrid = gridMode
            updateContent()
        }
        val toggleLp = LinearLayout.LayoutParams(dp(44), dp(44))
        toggleLp.leftMargin = dp(10)
        topRow.addView(toggle, toggleLp)

        // Cancel (only while searching)
        cancel.text = "Cancel"
        cancel.setTextColor(Color.WHITE)
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        cancel.setPadding(dp(14), dp(10), 0, dp(10))
        cancel.visibility = View.GONE
        cancel.setOnClickListener { exitSearch() }
        topRow.addView(
            cancel,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val rowLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        rowLp.bottomMargin = dp(12)
        body.addView(topRow, rowLp)

        // Category tiles
        tilesGrid.selector = ColorDrawable(Color.TRANSPARENT)
        tilesGrid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        tilesGrid.clipToPadding = false
        tilesGrid.isVerticalScrollBarEnabled = false
        tilesGrid.overScrollMode = View.OVER_SCROLL_NEVER
        tilesGrid.adapter = tilesAdapter
        tilesGrid.setOnItemClickListener { _, _, pos, _ -> openTile(tiles[pos]) }
        tilesGrid.setOnItemLongClickListener { _, view, pos, _ ->
            val tile = tiles[pos]
            if (tile.kind == KIND_CUSTOM) {
                host.showMenu(
                    view,
                    listOf(
                        "Rename" to { renameCategory(tile.title) },
                        "Delete category" to { deleteCategory(tile.title) }
                    )
                )
                true
            } else {
                false
            }
        }
        content.addView(
            tilesGrid,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // A-Z list (also used for search results)
        listView.divider = null
        listView.dividerHeight = 0
        listView.selector = ColorDrawable(Color.TRANSPARENT)
        listView.clipToPadding = false
        listView.isVerticalScrollBarEnabled = false
        listView.overScrollMode = View.OVER_SCROLL_NEVER
        listView.adapter = letterAdapter
        listView.setOnItemClickListener { _, _, pos, _ ->
            val e = rows[pos].app
            if (e != null) host.launch(e)
        }
        listView.setOnItemLongClickListener { _, view, pos, _ ->
            val e = rows[pos].app
            if (e != null) {
                host.longPress(view, e, menuItems(e))
                true
            } else {
                false
            }
        }
        listContainer.addView(
            listView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        sidebar.orientation = LinearLayout.VERTICAL
        for (l in LETTERS) {
            val tv = TextView(context)
            tv.text = l
            tv.setTextColor(Color.argb(190, 255, 255, 255))
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            tv.gravity = Gravity.CENTER
            sidebar.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        sidebar.setOnTouchListener { v, ev ->
            val a = ev.actionMasked
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                v.parent.requestDisallowInterceptTouchEvent(true)
                val idx = ((ev.y / max(1, v.height)) * LETTERS.size).toInt().coerceIn(0, LETTERS.size - 1)
                jumpTo(idx)
            }
            true
        }
        listContainer.addView(
            sidebar,
            FrameLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.RIGHT)
        )
        content.addView(
            listContainer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        body.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(
            body,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // Category popup panel
        panel.setBackgroundColor(Color.argb(140, 0, 0, 0))
        panel.visibility = View.GONE
        panel.isClickable = true
        panel.setOnClickListener { closePanel() }

        card.orientation = LinearLayout.VERTICAL
        card.isClickable = true
        card.setPadding(dp(16), dp(16), dp(16), dp(12))
        card.background = GradientDrawable().apply {
            setColor(Color.argb(238, 38, 38, 50))
            cornerRadius = dp(28).toFloat()
            setStroke(dp(1), 0x22FFFFFF)
        }
        panelTitle.setTextColor(Color.WHITE)
        panelTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        panelTitle.setPadding(dp(8), 0, 0, dp(12))
        card.addView(
            panelTitle,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        panelGrid.selector = ColorDrawable(Color.TRANSPARENT)
        panelGrid.verticalSpacing = dp(12)
        panelGrid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        panelGrid.isVerticalScrollBarEnabled = false
        panelGrid.overScrollMode = View.OVER_SCROLL_NEVER
        panelGrid.adapter = panelAdapter
        panelGrid.setOnItemClickListener { _, _, pos, _ -> host.launch(panelApps[pos]) }
        panelGrid.setOnItemLongClickListener { _, view, pos, _ ->
            val e = panelApps[pos]
            host.longPress(view, e, menuItems(e))
            true
        }
        card.addView(
            panelGrid,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        panel.addView(
            card,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        addView(
            panel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // Drop targets shown while dragging an app inside the drawer
        dropBar.orientation = LinearLayout.HORIZONTAL
        dropBar.visibility = View.GONE
        val chipLabels = listOf("Home Screen", "Dock", "Remove")
        val chipColors = intArrayOf(Color.rgb(48, 120, 220), Color.rgb(36, 150, 100), Color.rgb(200, 62, 72))
        for (i in 0 until 3) {
            val chip = TextView(context)
            chip.text = chipLabels[i]
            chip.setTextColor(Color.WHITE)
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            chip.setTypeface(null, android.graphics.Typeface.BOLD)
            chip.gravity = Gravity.CENTER
            chip.background = GradientDrawable().apply {
                setColor(chipColors[i])
                cornerRadius = dp(22).toFloat()
                setStroke(dp(2), Color.argb(160, 255, 255, 255))
            }
            chip.elevation = dp(6).toFloat()
            val clp = LinearLayout.LayoutParams(0, dp(48), 1f)
            clp.setMargins(dp(6), 0, dp(6), 0)
            dropBar.addView(chip, clp)
        }
        addView(
            dropBar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )

        updateContent()
    }

    // ---------- Public API ----------

    fun setApps(list: List<AppEntry>) {
        apps = list
        recompute()
    }

    fun refresh() {
        recompute()
        // Tiles slide in once the grid has been laid out.
        val vto = tilesGrid.viewTreeObserver
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                val o = tilesGrid.viewTreeObserver
                if (o.isAlive) o.removeOnGlobalLayoutListener(this)
                staggerIn()
            }
        })
    }

    private fun staggerIn() {
        if (tilesGrid.visibility != View.VISIBLE) return
        for (i in 0 until tilesGrid.childCount) {
            val c = tilesGrid.getChildAt(i)
            c.alpha = 0f
            c.translationY = dp(28).toFloat()
            c.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(min(i * 28L, 250L))
                .setDuration(260)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    fun setInsets(t: Int, b: Int, l: Int, r: Int) {
        insetL = l
        insetR = r
        body.setPadding(0, t + dp(16), 0, 0)
        val rlp = topRow.layoutParams as LinearLayout.LayoutParams
        rlp.leftMargin = l + dp(16)
        rlp.rightMargin = r + dp(16)
        topRow.layoutParams = rlp
        tilesGrid.setPadding(l + dp(16), dp(4), r + dp(16), b + dp(24))
        listView.setPadding(l + dp(8), 0, dp(32), b + dp(24))
        val slp = sidebar.layoutParams as FrameLayout.LayoutParams
        slp.rightMargin = r + dp(2)
        slp.topMargin = dp(6)
        slp.bottomMargin = b + dp(24)
        sidebar.layoutParams = slp
        val clp = card.layoutParams as FrameLayout.LayoutParams
        clp.setMargins(l + dp(20), t + dp(24), r + dp(20), b + dp(24))
        card.layoutParams = clp
        val blp = dropBar.layoutParams as FrameLayout.LayoutParams
        blp.setMargins(l + dp(12), 0, r + dp(12), b + dp(16))
        dropBar.layoutParams = blp
        updateColumns()
    }

    fun updateColumns() {
        val dm = resources.displayMetrics
        val wDp = dm.widthPixels / d
        val tileCols = (wDp / 170f).toInt().coerceIn(2, 5)
        val gap = dp(16)
        tilesGrid.numColumns = tileCols
        tilesGrid.horizontalSpacing = gap
        tilesGrid.verticalSpacing = dp(10)
        tileSide = max(dp(80), (dm.widthPixels - insetL - insetR - dp(32) - gap * (tileCols - 1)) / tileCols)
        panelGrid.numColumns = ((wDp - 72f) / 84f).toInt().coerceIn(3, 6)
        tilesAdapter.notifyDataSetChanged()
    }

    fun hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    // Back closes the panel, then leaves search. Returns true if it handled Back.
    fun handleBack(): Boolean {
        if (panel.visibility == View.VISIBLE) {
            closePanel()
            return true
        }
        if (searching) {
            exitSearch()
            return true
        }
        return false
    }

    // True while a swipe-down should NOT close the drawer.
    fun canScrollUp(): Boolean {
        if (panel.visibility == View.VISIBLE) return true
        val v: View = if (searching || !gridMode) listView else tilesGrid
        return v.canScrollVertically(-1)
    }

    fun reset() {
        closePanelInstant()
        exitSearch()
        tilesGrid.setSelection(0)
        listView.setSelection(0)
    }

    // ---------- Search ----------

    private fun enterSearch() {
        if (searching) return
        searching = true
        toggle.visibility = View.GONE
        cancel.visibility = View.VISIBLE
        cancel.alpha = 0f
        cancel.animate().alpha(1f).setDuration(160).start()
        updateContent()
    }

    private fun exitSearch() {
        val was = searching
        searching = false
        toggle.visibility = View.VISIBLE
        cancel.visibility = View.GONE
        if (search.text.isNotEmpty()) search.setText("")
        hideKeyboard()
        if (was) updateContent()
    }

    // ---------- Data ----------

    private fun recompute() {
        visibleApps = apps.filter { !prefs.isHidden(it.key) }
        buildTiles()
        buildRows()
        tilesAdapter.notifyDataSetChanged()
        letterAdapter.notifyDataSetChanged()
        updateContent()
    }

    private fun buildTiles() {
        val t = ArrayList<Tile>()
        val bucket = prefs.bucketNow()
        val last = prefs.lastLaunched

        val recent = visibleApps
            .filter { prefs.lastUsed(it.key) > 0L }
            .sortedByDescending { prefs.lastUsed(it.key) }
            .take(12)
        val recentTop = recent.take(4).map { it.key }.toSet()

        // Suggested = predicted, and never just a copy of Recently used.
        val suggested = visibleApps
            .filter { it.key !in recentTop && it.key != last }
            .map { it to prefs.suggestScore(it.key, bucket, last) }
            .filter { it.second > 0L }
            .sortedByDescending { it.second }
            .take(8)
            .map { it.first }
        if (suggested.isNotEmpty()) t.add(Tile("Suggested", suggested, suggested))
        if (recent.isNotEmpty()) t.add(Tile("Recently used", recent, recent))

        val cutoff = System.currentTimeMillis() - 14L * 24L * 60L * 60L * 1000L
        val added = visibleApps
            .filter { it.installTime > cutoff }
            .sortedByDescending { it.installTime }
            .take(12)
        if (added.isNotEmpty()) t.add(Tile("Recently added", added, added))

        val byCat = visibleApps.groupBy { Categorizer.categoryOf(it, prefs) }
        for (c in prefs.customCategories()) {
            val l = byCat[c] ?: emptyList()
            val pv = l
                .sortedWith(
                    compareByDescending<AppEntry> { prefs.score(it.key, bucket) }
                        .thenBy { it.label.lowercase() }
                )
                .take(7)
            t.add(Tile(c, l, pv, KIND_CUSTOM))
        }
        for (c in Categorizer.ORDER) {
            val l = byCat[c]
            if (l != null && l.isNotEmpty()) {
                // Most used apps take the big slots.
                val preview = l
                    .sortedWith(
                        compareByDescending<AppEntry> { prefs.score(it.key, bucket) }
                            .thenBy { it.label.lowercase() }
                    )
                    .take(7)
                t.add(Tile(c, l, preview, KIND_BUILTIN))
            }
        }
        val hiddenList = apps.filter { prefs.isHidden(it.key) }
        if (hiddenList.isNotEmpty()) t.add(Tile("Hidden", hiddenList, emptyList(), KIND_HIDDEN))
        t.add(Tile("New category", emptyList(), emptyList(), KIND_NEW))
        tiles = t
    }

    private fun letterOf(label: String): String {
        val c = label.trim().firstOrNull()?.uppercaseChar() ?: return "#"
        return if (c in 'A'..'Z') c.toString() else "#"
    }

    private fun buildRows() {
        val src = if (query.isEmpty()) visibleApps else visibleApps.filter { it.label.contains(query, ignoreCase = true) }
        val groups = src.groupBy { letterOf(it.label) }
        val r = ArrayList<Row>()
        for (l in LETTERS) {
            val g = groups[l] ?: continue
            r.add(Row(l, null))
            for (e in g) r.add(Row(null, e))
        }
        rows = r
    }

    private fun setVis(v: View, show: Boolean) {
        val now = v.visibility == View.VISIBLE
        if (show == now) return
        if (show) {
            v.visibility = View.VISIBLE
            v.alpha = 0f
            v.animate().alpha(1f).setDuration(170).start()
        } else {
            v.animate().cancel()
            v.visibility = View.GONE
            v.alpha = 1f
        }
    }

    private fun updateContent() {
        val listMode = (searching || !gridMode) && !dragActive
        setVis(tilesGrid, !listMode)
        setVis(listContainer, listMode)
        toggle.kind = if (gridMode) IconView.LIST else IconView.GRID
        toggle.invalidate()
    }

    private fun jumpTo(idx: Int) {
        var i = idx
        while (i < LETTERS.size) {
            val l = LETTERS[i]
            val pos = rows.indexOfFirst { it.letter == l }
            if (pos >= 0) {
                listView.setSelection(pos)
                return
            }
            i++
        }
        listView.setSelection(max(0, rows.size - 1))
    }

    // ---------- Menus and panel ----------

    private fun menuItems(e: AppEntry): List<Pair<String, () -> Unit>> {
        val hidden = prefs.isHidden(e.key)
        return listOf(
            "Add to Home Screen" to { host.addToHome(e) },
            "Add to Dock" to { host.addToDock(e) },
            (if (hidden) "Show in drawer" else "Hide from drawer") to {
                prefs.setHidden(e.key, !hidden)
                if (!hidden) host.hideApp(e)
                closePanel()
                recompute()
            },
            "Move to category" to { chooseCategory(e) },
            "Delete app" to { host.uninstall(e) },
            "App info" to { host.appInfo(e) }
        )
    }

    private fun chooseCategory(e: AppEntry) {
        val items = ArrayList<Pair<String, () -> Unit>>()
        for (c in prefs.customCategories() + Categorizer.ORDER) {
            items.add(c to {
                prefs.setCategory(e.key, c)
                closePanel()
                recompute()
            })
        }
        items.add("New category..." to { newCategory(e) })
        host.showMenu(pill, items)
    }

    private fun validName(name: String, ignore: String?): Boolean {
        val n = name.trim()
        if (n.isEmpty() || n.length > 20) return false
        val all = Categorizer.ORDER + prefs.customCategories() +
            listOf("Suggested", "Recently used", "Recently added", "Hidden", "New category")
        return all.none { it.equals(n, ignoreCase = true) && !it.equals(ignore, ignoreCase = true) }
    }

    // Creates a category; if an app is given, moves it in.
    private fun newCategory(assign: AppEntry?) {
        host.prompt("New category", "") { name ->
            if (!validName(name, null)) {
                host.toast("Pick a different name")
                return@prompt
            }
            val n = name.trim()
            prefs.addCategory(n)
            if (assign != null) prefs.setCategory(assign.key, n)
            closePanel()
            recompute()
        }
    }

    private fun renameCategory(old: String) {
        host.prompt("Rename category", old) { name ->
            if (!validName(name, old)) {
                host.toast("Pick a different name")
                return@prompt
            }
            prefs.renameCategory(old, name.trim())
            recompute()
        }
    }

    private fun deleteCategory(name: String) {
        prefs.deleteCategory(name)
        recompute()
    }

    private fun openTile(tile: Tile) {
        when (tile.kind) {
            KIND_NEW -> newCategory(null)
            KIND_HIDDEN -> host.requestAuth { showPanel(tile) }
            else -> showPanel(tile)
        }
    }

    private fun showPanel(tile: Tile) {
        panelApps = tile.apps
        panelTitle.text = tile.title
        panelAdapter.notifyDataSetChanged()
        panelGrid.setSelection(0)
        panel.animate().cancel()
        card.animate().cancel()
        panel.alpha = 0f
        panel.visibility = View.VISIBLE
        card.scaleX = 0.92f
        card.scaleY = 0.92f
        card.animate().scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(OvershootInterpolator(1.05f)).start()
        panel.animate().alpha(1f).setDuration(190).start()
    }

    private fun closePanel() {
        if (panel.visibility != View.VISIBLE) return
        panel.animate().cancel()
        panel.animate().alpha(0f).setDuration(140).withEndAction {
            panel.visibility = View.GONE
        }.start()
    }

    private fun closePanelInstant() {
        panel.animate().cancel()
        card.animate().cancel()
        panel.visibility = View.GONE
    }

    // ---------- Dragging apps inside the drawer ----------

    private fun hit(v: View, x: Float, y: Float): Boolean {
        val loc = IntArray(2)
        v.getLocationInWindow(loc)
        return x >= loc[0] && x <= loc[0] + v.width && y >= loc[1] && y <= loc[1] + v.height
    }

    fun dragBegin(e: AppEntry) {
        dragActive = true
        dragEntry = e
        closePanelInstant()
        hideKeyboard()
        updateContent()
        dropBar.animate().cancel()
        dropBar.visibility = View.VISIBLE
        dropBar.alpha = 1f
        dropBar.translationY = dp(70).toFloat()
        dropBar.bringToFront()
        dropBar.animate().translationY(0f).setDuration(220).start()
    }

    // Returns what is under the finger: 0 nothing, 1 Home chip, 2 Dock chip, 3 Remove chip, 4 tile.
    fun dragHover(x: Float, y: Float): Int {
        var target = 0
        var view: View? = null
        var tile: Tile? = null
        for (i in 0 until dropBar.childCount) {
            val c = dropBar.getChildAt(i)
            if (hit(c, x, y)) {
                target = i + 1
                view = c
            }
        }
        if (target == 0 && tilesGrid.visibility == View.VISIBLE) {
            for (i in 0 until tilesGrid.childCount) {
                val c = tilesGrid.getChildAt(i)
                if (hit(c, x, y)) {
                    val pos = tilesGrid.getPositionForView(c)
                    if (pos >= 0 && pos < tiles.size) {
                        tile = tiles[pos]
                        target = 4
                        view = c
                    }
                }
            }
        }
        if (view !== hoverView) {
            hoverView?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(120)?.start()
            view?.animate()?.scaleX(1.1f)?.scaleY(1.1f)?.setDuration(120)?.start()
            hoverView = view
        }
        hoverTarget = target
        hoverTile = tile
        return target
    }

    fun dragAbort() {
        dragEnd(0f, 0f, true)
    }

    fun dragEnd(x: Float, y: Float, cancelled: Boolean) {
        val e = dragEntry
        val target = hoverTarget
        val tile = hoverTile
        hoverView?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(120)?.start()
        hoverView = null
        hoverTarget = 0
        hoverTile = null
        dragActive = false
        dragEntry = null
        dropBar.animate().translationY(dp(70).toFloat()).setDuration(160).withEndAction {
            dropBar.visibility = View.GONE
        }.start()
        if (!cancelled && e != null) {
            when (target) {
                1 -> host.addToHome(e)
                2 -> host.addToDock(e)
                3 -> {
                    if (prefs.categoryOverride(e.key) != null) {
                        prefs.clearCategory(e.key)
                        host.toast("Back to its automatic category")
                    } else {
                        host.toast("Already in its automatic category")
                    }
                }
                4 -> if (tile != null) dropOnTile(e, tile)
            }
        }
        recompute()
    }

    private fun dropOnTile(e: AppEntry, tile: Tile) {
        when (tile.kind) {
            KIND_BUILTIN, KIND_CUSTOM -> {
                prefs.setCategory(e.key, tile.title)
                host.toast("Moved to " + tile.title)
            }
            KIND_HIDDEN -> {
                prefs.setHidden(e.key, true)
                host.hideApp(e)
                host.toast("App hidden")
            }
            KIND_NEW -> newCategory(e)
            else -> host.toast("Can't move apps into " + tile.title)
        }
    }

    // ---------- Tile look ----------

    // Own palette: a soft tint per category.
    private fun tint(title: String): Int = when (title) {
        "Suggested" -> Color.rgb(200, 205, 225)
        "Recently used" -> Color.rgb(70, 200, 195)
        "Recently added" -> Color.rgb(170, 120, 255)
        "Social" -> Color.rgb(80, 140, 255)
        "Media" -> Color.rgb(255, 100, 140)
        "Games" -> Color.rgb(80, 215, 130)
        "Productivity" -> Color.rgb(255, 185, 70)
        "Education" -> Color.rgb(130, 120, 255)
        "Shopping" -> Color.rgb(255, 135, 75)
        "Travel" -> Color.rgb(70, 200, 255)
        "Finance" -> Color.rgb(60, 205, 165)
        "Tools" -> Color.rgb(140, 155, 185)
        "Hidden" -> Color.rgb(120, 120, 135)
        else -> Color.HSVToColor(floatArrayOf((abs(title.hashCode()) % 360).toFloat(), 0.45f, 1f))
    }

    private fun tileBackground(title: String): Drawable {
        val c = tint(title)
        val top = Color.argb(120, Color.red(c), Color.green(c), Color.blue(c))
        val bottom = Color.argb(48, Color.red(c), Color.green(c), Color.blue(c))
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, bottom))
        g.cornerRadius = dp(28).toFloat()
        g.setStroke(dp(1), Color.argb(70, 255, 255, 255))
        return g
    }

    private fun placeholder(): Drawable {
        val g = GradientDrawable()
        g.setColor(0x40FFFFFF)
        g.cornerRadius = dp(12).toFloat()
        return g
    }

    // Mini icons in a tile's corner cluster open the category instead of launching.
    private fun bindMini(iv: ImageView, e: AppEntry?, tile: Tile) {
        if (e == null) {
            iv.setImageDrawable(null)
            iv.setOnClickListener(null)
            iv.setOnLongClickListener(null)
            iv.isClickable = false
            iv.isLongClickable = false
            return
        }
        iv.setImageDrawable(e.icon)
        iv.setOnClickListener { openTile(tile) }
        iv.setOnLongClickListener {
            host.longPress(iv, e, menuItems(e))
            true
        }
    }

    private fun bindIcon(iv: ImageView, e: AppEntry?) {
        if (e == null) {
            iv.setImageDrawable(null)
            iv.setOnClickListener(null)
            iv.setOnLongClickListener(null)
            iv.isClickable = false
            iv.isLongClickable = false
            return
        }
        iv.setImageDrawable(e.icon)
        iv.setOnClickListener { host.launch(e) }
        iv.setOnLongClickListener {
            host.longPress(iv, e, menuItems(e))
            true
        }
    }

    // ---------- Adapters ----------

    private inner class AppGridAdapter(val source: () -> List<AppEntry>) : BaseAdapter() {
        override fun getCount(): Int = source().size
        override fun getItem(position: Int): Any = source()[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val c = convertView ?: buildCell(context, 56)
            bindCell(c, source()[position])
            return c
        }
    }

    private inner class TilesAdapter : BaseAdapter() {
        override fun getCount(): Int = tiles.size
        override fun getItem(position: Int): Any = tiles[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val root = (convertView as? LinearLayout) ?: makeTile()
            bindTile(root, tiles[position])
            return root
        }

        // One slot = a big icon, or (bottom-right) a 2x2 cluster of mini icons.
        private fun makeSlot(): FrameLayout {
            val f = FrameLayout(context)
            val big = ImageView(context)
            big.scaleType = ImageView.ScaleType.FIT_CENTER
            big.setPadding(dp(5), dp(5), dp(5), dp(5))
            f.addView(big, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val mini = LinearLayout(context)
            mini.orientation = LinearLayout.VERTICAL
            mini.visibility = View.GONE
            for (r in 0 until 2) {
                val row = LinearLayout(context)
                row.orientation = LinearLayout.HORIZONTAL
                for (c in 0 until 2) {
                    val iv = ImageView(context)
                    iv.scaleType = ImageView.ScaleType.FIT_CENTER
                    iv.setPadding(dp(2), dp(2), dp(2), dp(2))
                    row.addView(iv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                }
                mini.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            }
            f.addView(mini, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return f
        }

        private fun makeTile(): LinearLayout {
            val root = LinearLayout(context)
            root.orientation = LinearLayout.VERTICAL
            val box = LinearLayout(context)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(8), dp(8), dp(8), dp(8))
            for (r in 0 until 2) {
                val row = LinearLayout(context)
                row.orientation = LinearLayout.HORIZONTAL
                for (c in 0 until 2) {
                    row.addView(makeSlot(), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                }
                box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            }
            root.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            val label = TextView(context)
            label.setTextColor(Color.WHITE)
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            label.gravity = Gravity.CENTER
            label.maxLines = 1
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6)
            root.addView(label, lp)
            return root
        }

        private fun bindTile(root: LinearLayout, tile: Tile) {
            root.layoutParams = AbsListView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                tileSide + dp(34)
            )
            val box = root.getChildAt(0) as LinearLayout
            val isNew = tile.kind == KIND_NEW
            box.background = if (isNew) NewTileDrawable(d) else tileBackground(tile.title)
            val isHidden = tile.kind == KIND_HIDDEN || (tile.kind == KIND_CUSTOM && tile.preview.isEmpty())
            val cluster = tile.preview.size > 4
            for (i in 0 until 4) {
                val row = box.getChildAt(i / 2) as LinearLayout
                val slot = row.getChildAt(i % 2) as FrameLayout
                val big = slot.getChildAt(0) as ImageView
                val mini = slot.getChildAt(1) as LinearLayout
                if (isNew) {
                    mini.visibility = View.GONE
                    bindIcon(big, null)
                } else if (isHidden) {
                    // Never show real icons of hidden apps.
                    mini.visibility = View.GONE
                    bindIcon(big, null)
                    big.setImageDrawable(placeholder())
                } else if (i == 3 && cluster) {
                    bindIcon(big, null)
                    mini.visibility = View.VISIBLE
                    for (j in 0 until 4) {
                        val mr = mini.getChildAt(j / 2) as LinearLayout
                        val iv = mr.getChildAt(j % 2) as ImageView
                        bindMini(iv, tile.preview.getOrNull(3 + j), tile)
                    }
                } else {
                    mini.visibility = View.GONE
                    bindIcon(big, tile.preview.getOrNull(i))
                }
            }
            (root.getChildAt(1) as TextView).text = tile.title
        }
    }

    private inner class LetterAdapter : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getViewTypeCount(): Int = 2
        override fun getItemViewType(position: Int): Int = if (rows[position].app == null) 0 else 1
        override fun isEnabled(position: Int): Boolean = rows[position].app != null
        override fun areAllItemsEnabled(): Boolean = false

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val r = rows[position]
            val e = r.app
            if (e == null) {
                val tv = (convertView as? TextView) ?: TextView(context).apply {
                    setTextColor(Color.argb(200, 255, 255, 255))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                    setPadding(dp(16), dp(14), 0, dp(4))
                }
                tv.text = r.letter
                return tv
            }
            val row = (convertView as? LinearLayout) ?: makeRow()
            (row.getChildAt(0) as ImageView).setImageDrawable(e.icon)
            (row.getChildAt(1) as TextView).text = e.label
            return row
        }

        private fun makeRow(): LinearLayout {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(6), dp(8), dp(6))
            val iv = ImageView(context)
            row.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)))
            val tv = TextView(context)
            tv.setTextColor(Color.WHITE)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            tv.maxLines = 1
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.leftMargin = dp(16)
            row.addView(tv, lp)
            return row
        }
    }
}
