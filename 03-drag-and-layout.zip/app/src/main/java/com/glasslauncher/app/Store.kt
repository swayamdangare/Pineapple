package com.glasslauncher.app

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.UserHandle
import org.json.JSONArray
import org.json.JSONObject

class AppEntry(
    val label: String,
    val icon: Drawable,
    val component: ComponentName,
    val user: UserHandle
) {
    val key: String = component.flattenToString()
    fun newIcon(): Drawable = icon.constantState?.newDrawable()?.mutate() ?: icon
}

// One icon on a Home page. cell is an index 0..capacity-1 (row-major).
class HomeItem(val key: String, var page: Int, var cell: Int)

class LayoutData {
    val home = ArrayList<HomeItem>()
    val dock = ArrayList<String>()
}

class LayoutStore(context: Context) {
    private val prefs = context.getSharedPreferences("layout", Context.MODE_PRIVATE)

    fun load(capacity: Int): LayoutData? {
        val raw2 = prefs.getString("layout_v2", null)
        if (raw2 != null) {
            try {
                val o = JSONObject(raw2)
                val l = LayoutData()
                val h = o.getJSONArray("home")
                for (i in 0 until h.length()) {
                    val x = h.getJSONObject(i)
                    l.home.add(HomeItem(x.getString("k"), x.getInt("p"), x.getInt("c")))
                }
                val d = o.getJSONArray("dock")
                for (i in 0 until d.length()) l.dock.add(d.getString(i))
                return l
            } catch (e: Exception) {
                // fall through to older format
            }
        }
        val raw1 = prefs.getString("layout_v1", null) ?: return null
        return try {
            val o = JSONObject(raw1)
            val l = LayoutData()
            val h = o.getJSONArray("home")
            for (i in 0 until h.length()) {
                l.home.add(HomeItem(h.getString(i), i / capacity, i % capacity))
            }
            val d = o.getJSONArray("dock")
            for (i in 0 until d.length()) l.dock.add(d.getString(i))
            l
        } catch (e: Exception) {
            null
        }
    }

    fun save(l: LayoutData) {
        val o = JSONObject()
        o.put("v", 2)
        val h = JSONArray()
        for (item in l.home) {
            val x = JSONObject()
            x.put("k", item.key)
            x.put("p", item.page)
            x.put("c", item.cell)
            h.put(x)
        }
        o.put("home", h)
        o.put("dock", JSONArray(l.dock))
        prefs.edit().putString("layout_v2", o.toString()).apply()
    }
}
