package com.glasslauncher.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.max

class MainActivity : Activity(), RootLayout.Gesture, RootLayout.DragHost {

    companion object {
        const val MAX_DOCK = 5
        const val SRC_HOME = 0
        const val SRC_DOCK = 1
        const val SRC_DRAWER = 2
    }

    private class DragState(val entry: AppEntry, val source: Int)

    private lateinit var launcherApps: LauncherApps
    private lateinit var store: LayoutStore
    private lateinit var root: RootLayout
    private lateinit var scroller: PageScroller
    private lateinit var dots: DotsView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var drawerGrid: GridView
    private lateinit var dragLayer: FrameLayout
    private val drawerAdapter = DrawerAdapter()

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var apps: List<AppEntry> = emptyList()
    private var appMap: Map<String, AppEntry> = emptyMap()
    private var shown: List<AppEntry> = emptyList()
    private var data = LayoutData()
    private var layoutLoaded = false

    private var topInset = 0
    private var bottomInset = 0
    private var leftInset = 0
    private var rightInset = 0
    private var currentPage = 0
    private var drawerOpen = false
    private var dragBase = 0f

    // Grid metrics of the last Home build (used to map touches to cells).
    private var mCols = 4
    private var mRows = 6
    private var mCw = 1
    private var mCh = 1
    private var mPadL = 0
    private var mPadT = 0
    private var mW = 1

    // Long-press and drag state.
    private var armedDrag: DragState? = null
    private var armedView: View? = null
    private var armedMenu: List<Pair<String, () -> Unit>>? = null
    private var drag: DragState? = null
    private var ghost: ImageView? = null
    private var highlight: View? = null
    private var popup: PopupMenu? = null
    private var hoverPage = 0
    private var hoverCell = 0
    private var dockHover = false
    private var edgeDir = 0

    private val edgeFlip = object : Runnable {
        override fun run() {
            if (edgeDir == 0 || drag == null) return
            val target = (currentPage + edgeDir).coerceIn(0, max(0, scroller.pageCount - 1))
            if (target != currentPage) {
                currentPage = target
                scroller.smoothScrollTo(target * mW, 0)
            }
            ui.postDelayed(this, 700)
        }
    }

    // Event-driven: fires only when apps are installed, removed or updated.
    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
            reload()
            if (packageName != null) ui.postDelayed({ purge(packageName) }, 3000)
        }
        override fun onPackageAdded(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackageChanged(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { reload() }
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { reload() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    // ---------- Device and grid helpers ----------

    private fun isTablet(): Boolean = resources.configuration.smallestScreenWidthDp >= 600
    private fun isLandscape(): Boolean = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private fun dockVertical(): Boolean = isLandscape() && !isTablet()

    // Cells per page are fixed; only their arrangement changes with orientation.
    private fun portraitCols(): Int = if (isTablet()) 5 else 4
    private fun portraitRows(): Int = 6
    private fun capacity(): Int = portraitCols() * portraitRows()
    private fun gridCols(): Int = if (isLandscape()) portraitRows() else portraitCols()
    private fun gridRows(): Int = if (isLandscape()) portraitCols() else portraitRows()

    private fun colsFor(widthPx: Int): Int {
        val wDp = widthPx / resources.displayMetrics.density
        return (wDp / 92f).toInt().coerceIn(4, 8)
    }

    // ---------- Setup ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launcherApps = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        store = LayoutStore(this)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        root = RootLayout(this)
        root.gesture = this
        root.dragHost = this

        scroller = PageScroller(this)
        scroller.onSettled = { currentPage = it }
        scroller.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, oR, ob ->
            if (r - l != oR - ol || b - t != ob - ot) scroller.post { rebuildHome() }
        }
        root.addView(
            scroller,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        dots = DotsView(this)
        scroller.onPosition = { dots.position = it }
        root.addView(
            dots,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
        )

        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                setColor(0x55FFFFFF)
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        root.addView(
            dock,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
        )

        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(242, 16, 16, 24))
            isClickable = true
            visibility = View.GONE
        }
        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Color.argb(153, 255, 255, 255))
            setTextColor(Color.WHITE)
            textSize = 16f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                setColor(0x26FFFFFF)
                cornerRadius = dp(14).toFloat()
            }
            setOnEditorActionListener { _, _, _ ->
                hideKeyboard()
                true
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    applyFilter(s?.toString() ?: "")
                }
            })
        }
        val searchLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        searchLp.bottomMargin = dp(12)
        drawer.addView(search, searchLp)

        drawerGrid = GridView(this).apply {
            selector = ColorDrawable(Color.TRANSPARENT)
            verticalSpacing = dp(14)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            clipToPadding = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            adapter = drawerAdapter
            setOnItemClickListener { _, _, pos, _ ->
                launch(shown[pos])
                closeDrawer()
            }
            setOnItemLongClickListener { _, view, pos, _ ->
                val e = shown[pos]
                armLongPress(
                    view, e, SRC_DRAWER,
                    listOf(
                        "Add to Home Screen" to { addToHome(e) },
                        "Add to Dock" to { addToDock(e) },
                        "App info" to { appInfo(e) }
                    )
                )
                true
            }
        }
        drawer.addView(
            drawerGrid,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(
            drawer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        dragLayer = FrameLayout(this)
        root.addView(
            dragLayer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        updateDrawerColumns()

        root.setOnApplyWindowInsetsListener { _, insets ->
            var t = insets.stableInsetTop
            var b = insets.stableInsetBottom
            var l = insets.stableInsetLeft
            var r = insets.stableInsetRight
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = insets.displayCutout
                if (cut != null) {
                    t = max(t, cut.safeInsetTop)
                    b = max(b, cut.safeInsetBottom)
                    l = max(l, cut.safeInsetLeft)
                    r = max(r, cut.safeInsetRight)
                }
            }
            if (t != topInset || b != bottomInset || l != leftInset || r != rightInset) {
                topInset = t
                bottomInset = b
                leftInset = l
                rightInset = r
                applyChrome()
                scroller.post { rebuildHome() }
            }
            insets
        }

        setContentView(root)
        applyChrome()
        launcherApps.registerCallback(callback)
        reload()
    }

    // Positions the Dock and page dots for the current orientation and insets.
    private fun applyChrome() {
        val vertical = dockVertical()
        val dlp = dock.layoutParams as FrameLayout.LayoutParams
        if (vertical) {
            // Phones in landscape: Dock on the right edge.
            dock.orientation = LinearLayout.VERTICAL
            dlp.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            dlp.bottomMargin = 0
            dlp.rightMargin = rightInset + dp(16)
            dock.minimumWidth = dp(72)
            dock.minimumHeight = dp(96)
        } else {
            dock.orientation = LinearLayout.HORIZONTAL
            dlp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            dlp.bottomMargin = bottomInset + dp(16)
            dlp.rightMargin = 0
            dock.minimumWidth = dp(96)
            dock.minimumHeight = dp(72)
        }
        dock.layoutParams = dlp

        val tlp = dots.layoutParams as FrameLayout.LayoutParams
        tlp.bottomMargin = if (vertical) bottomInset + dp(10) else bottomInset + dp(16 + 72 + 8)
        dots.layoutParams = tlp

        drawer.setPadding(0, topInset + dp(16), 0, 0)
        val slp = search.layoutParams as LinearLayout.LayoutParams
        slp.leftMargin = leftInset + dp(16)
        slp.rightMargin = rightInset + dp(16)
        search.layoutParams = slp
        drawerGrid.setPadding(leftInset + dp(12), dp(8), rightInset + dp(12), bottomInset + dp(24))
    }

    private fun updateDrawerColumns() {
        drawerGrid.numColumns = colsFor(resources.displayMetrics.widthPixels)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateDrawerColumns()
        applyChrome()
        buildDock()
        scroller.post { rebuildHome() }
    }

    // ---------- Data ----------

    // Icons are drawn once into hardware bitmaps: cheap to draw, light on app memory.
    private fun renderIcon(d: Drawable): Drawable {
        val s = dp(60)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, s, s)
        d.draw(c)
        val hw: Bitmap? = try {
            bmp.copy(Bitmap.Config.HARDWARE, false)
        } catch (e: Exception) {
            null
        }
        return if (hw != null) {
            bmp.recycle()
            BitmapDrawable(resources, hw)
        } else {
            BitmapDrawable(resources, bmp)
        }
    }

    private fun reload() {
        worker.execute {
            val list: List<AppEntry> = try {
                launcherApps.getActivityList(null, Process.myUserHandle())
                    .filter { it.componentName.packageName != packageName }
                    .map { AppEntry(it.label.toString(), renderIcon(it.getBadgedIcon(0)), it.componentName, it.user) }
                    .sortedBy { it.label.lowercase() }
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (list.isEmpty() && apps.isNotEmpty()) return@runOnUiThread
                apps = list
                appMap = list.associateBy { it.key }
                if (!layoutLoaded && list.isNotEmpty()) {
                    val saved = store.load(capacity())
                    if (saved != null) {
                        data = saved
                    } else {
                        data = defaultLayout()
                    }
                    normalizeLayout()
                    store.save(data)
                    layoutLoaded = true
                }
                applyFilter(search.text.toString())
                rebuildHome()
                buildDock()
            }
        }
    }

    private fun defaultLayout(): LayoutData {
        val l = LayoutData()
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (p in probes) {
            val pkg: String? = try {
                packageManager.resolveActivity(p, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            } catch (e: Exception) {
                null
            }
            if (pkg == null) continue
            val e = apps.firstOrNull { it.component.packageName == pkg } ?: continue
            if (e.key !in l.dock) l.dock.add(e.key)
        }
        for (e in apps) {
            if (l.dock.size >= 4) break
            if (e.key !in l.dock) l.dock.add(e.key)
        }
        var cell = 0
        for (e in apps) {
            if (cell >= 20) break
            if (e.key in l.dock) continue
            l.home.add(HomeItem(e.key, 0, cell))
            cell++
        }
        return l
    }

    // Repairs a saved layout: duplicates, bad cells, collisions, empty pages.
    private fun normalizeLayout() {
        val cap = capacity()
        val seen = HashSet<String>()
        val used = HashSet<Int>()
        val clean = ArrayList<HomeItem>()
        val loose = ArrayList<HomeItem>()
        for (item in data.home) {
            if (!seen.add(item.key)) continue
            val id = item.page * cap + item.cell
            if (item.page < 0 || item.cell < 0 || item.cell >= cap || !used.add(id)) {
                loose.add(item)
            } else {
                clean.add(item)
            }
        }
        for (item in loose) {
            val id = findFree(0, used)
            used.add(id)
            item.page = id / cap
            item.cell = id % cap
            clean.add(item)
        }
        data.home.clear()
        data.home.addAll(clean)
        val dseen = HashSet<String>()
        data.dock.retainAll { dseen.add(it) }
        compactPages()
    }

    private fun usedSlots(except: HomeItem?): HashSet<Int> {
        val cap = capacity()
        val s = HashSet<Int>()
        for (item in data.home) {
            if (item !== except) s.add(item.page * cap + item.cell)
        }
        return s
    }

    private fun findFree(from: Int, used: Set<Int>): Int {
        var i = max(0, from)
        while (used.contains(i)) i++
        return i
    }

    // Renumbers pages so there are no empty pages in between.
    private fun compactPages() {
        val pages = data.home.map { it.page }.distinct().sorted()
        val map = HashMap<Int, Int>()
        pages.forEachIndexed { i, p -> map[p] = i }
        for (item in data.home) item.page = map[item.page] ?: 0
    }

    // Remove saved icons of an app that is really gone (not just being updated).
    private fun purge(pkg: String) {
        try {
            if (launcherApps.getActivityList(pkg, Process.myUserHandle()).isNotEmpty()) return
        } catch (e: Exception) {
            return
        }
        val prefix = "$pkg/"
        val a = data.home.removeAll { it.key.startsWith(prefix) }
        val b = data.dock.removeAll { it.startsWith(prefix) }
        if (a || b) {
            compactPages()
            store.save(data)
            rebuildHome()
            buildDock()
        }
    }

    private fun applyFilter(q: String) {
        val query = q.trim()
        shown = if (query.isEmpty()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
        drawerAdapter.notifyDataSetChanged()
    }

    // ---------- Home ----------

    private fun rebuildHome() {
        val w = scroller.width
        val h = scroller.height
        if (w <= 0 || h <= 0) return

        val vertical = dockVertical()
        val padTop = topInset + dp(if (vertical) 12 else 24)
        val padBottom = bottomInset + dp(if (vertical) 32 else 124)
        val padLeft = leftInset + dp(12)
        val padRight = rightInset + dp(12) + (if (vertical) dp(96) else 0)
        val cols = gridCols()
        val rows = gridRows()
        val cw = max(1, (w - padLeft - padRight) / cols)
        val ch = max(1, (h - padTop - padBottom) / rows)
        mCols = cols
        mRows = rows
        mCw = cw
        mCh = ch
        mPadL = padLeft
        mPadT = padTop
        mW = w
        val iconDp = ((ch / resources.displayMetrics.density) - 26f).toInt().coerceIn(30, 56)

        val dragKey = drag?.entry?.key
        val maxPage = data.home.maxOfOrNull { it.page } ?: 0
        // While dragging, one extra empty page lets you start a new page.
        val pageCount = maxPage + 1 + (if (drag != null) 1 else 0)

        scroller.content.removeAllViews()
        for (p in 0 until pageCount) {
            val grid = IconGrid(this, cols, rows)
            grid.setPadding(padLeft, padTop, padRight, padBottom)
            for (item in data.home) {
                if (item.page != p || item.key == dragKey) continue
                val e = appMap[item.key] ?: continue
                grid.addCell(homeCell(e, iconDp), item.cell)
            }
            scroller.content.addView(grid, LinearLayout.LayoutParams(w, h))
        }
        scroller.pageCount = pageCount
        currentPage = currentPage.coerceIn(0, pageCount - 1)
        dots.count = pageCount

        scroller.content.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(
                v: View?, l: Int, t: Int, r: Int, b: Int,
                ol: Int, ot: Int, oR: Int, ob: Int
            ) {
                v?.removeOnLayoutChangeListener(this)
                scroller.scrollTo(currentPage * w, 0)
                dots.position = currentPage.toFloat()
            }
        })
    }

    private fun homeCell(e: AppEntry, iconDp: Int): View {
        val c = buildCell(this, iconDp)
        bindCell(c, e)
        c.setOnClickListener { launch(e) }
        c.setOnLongClickListener {
            armLongPress(
                c, e, SRC_HOME,
                listOf(
                    "Remove from Home Screen" to { removeFromHome(e) },
                    "App info" to { appInfo(e) }
                )
            )
            true
        }
        return c
    }

    private fun buildDock() {
        dock.removeAllViews()
        val vertical = dockVertical()
        val dragKey = drag?.entry?.key
        val list = data.dock.filter { it != dragKey }.mapNotNull { appMap[it] }
        for (e in list) {
            val iv = ImageView(this)
            iv.setImageDrawable(e.newIcon())
            val lp = LinearLayout.LayoutParams(dp(52), dp(52))
            if (vertical) lp.setMargins(0, dp(6), 0, dp(6)) else lp.setMargins(dp(6), 0, dp(6), 0)
            iv.layoutParams = lp
            iv.setOnClickListener { launch(e) }
            iv.setOnLongClickListener {
                armLongPress(
                    iv, e, SRC_DOCK,
                    listOf(
                        "Remove from Dock" to { removeFromDock(e) },
                        "App info" to { appInfo(e) }
                    )
                )
                true
            }
            dock.addView(iv)
        }
    }

    // ---------- Actions ----------

    private fun showMenu(anchor: View, items: List<Pair<String, () -> Unit>>) {
        val p = PopupMenu(this, anchor)
        items.forEachIndexed { i, item -> p.menu.add(0, i, i, item.first) }
        p.setOnMenuItemClickListener { m ->
            items[m.itemId].second()
            true
        }
        p.setOnDismissListener { popup = null }
        popup = p
        p.show()
    }

    private fun addToHome(e: AppEntry) {
        if (data.home.any { it.key == e.key }) {
            toast("Already on Home Screen")
            return
        }
        val cap = capacity()
        val id = findFree(0, usedSlots(null))
        data.dock.remove(e.key)
        data.home.add(HomeItem(e.key, id / cap, id % cap))
        compactPages()
        store.save(data)
        currentPage = data.home.firstOrNull { it.key == e.key }?.page ?: 0
        rebuildHome()
        buildDock()
        toast("Added to Home Screen")
        closeDrawer()
    }

    private fun addToDock(e: AppEntry) {
        if (data.dock.contains(e.key)) {
            toast("Already in Dock")
            return
        }
        if (data.dock.size >= MAX_DOCK) {
            toast("Dock is full. Remove an app first.")
            return
        }
        data.home.removeAll { it.key == e.key }
        data.dock.add(e.key)
        compactPages()
        store.save(data)
        rebuildHome()
        buildDock()
        toast("Added to Dock")
    }

    private fun removeFromHome(e: AppEntry) {
        data.home.removeAll { it.key == e.key }
        compactPages()
        store.save(data)
        rebuildHome()
    }

    private fun removeFromDock(e: AppEntry) {
        data.dock.remove(e.key)
        store.save(data)
        buildDock()
    }

    private fun appInfo(e: AppEntry) {
        try {
            launcherApps.startAppDetailsActivity(e.component, e.user, null, null)
        } catch (ex: Exception) {
            toast("Can't open app info")
        }
    }

    private fun launch(e: AppEntry) {
        try {
            launcherApps.startMainActivity(e.component, e.user, null, null)
        } catch (ex: Exception) {
            toast("Can't open " + e.label)
        }
    }

    // ---------- Long-press, menu and drag ----------

    // Long-press lifts the icon. Move the finger to drag; lift it in place for the menu.
    private fun armLongPress(view: View, entry: AppEntry, source: Int, items: List<Pair<String, () -> Unit>>) {
        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        view.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
        armedDrag = DragState(entry, source)
        armedView = view
        armedMenu = items
        root.arm()
    }

    override fun onArmedEnd(released: Boolean) {
        val menu = armedMenu
        val v = armedView
        armedDrag = null
        armedMenu = null
        armedView = null
        v?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(120)?.start()
        if (released && menu != null && v != null) showMenu(v, menu)
    }

    override fun onDragStart(x: Float, y: Float): Boolean {
        val st = armedDrag ?: return false
        armedDrag = null
        armedMenu = null
        armedView = null
        popup?.dismiss()
        popup = null
        hideKeyboard()
        drag = st
        if (drawerOpen) closeDrawer()

        val size = dp(60)
        val g = ImageView(this)
        g.setImageDrawable(st.entry.newIcon())
        g.alpha = 0.92f
        g.layoutParams = FrameLayout.LayoutParams(size, size)
        dragLayer.addView(g)
        ghost = g

        val hl = View(this)
        hl.background = GradientDrawable().apply {
            setColor(0x33FFFFFF)
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), 0x55FFFFFF)
        }
        hl.layoutParams = FrameLayout.LayoutParams(max(1, mCw - dp(12)), max(1, mCh - dp(12)))
        hl.visibility = View.INVISIBLE
        dragLayer.addView(hl, 0)
        highlight = hl

        dockHover = false
        edgeDir = 0
        rebuildHome()
        buildDock()
        return true
    }

    private fun isOverDock(x: Float, y: Float): Boolean {
        val loc = IntArray(2)
        dock.getLocationInWindow(loc)
        val m = dp(24)
        return x >= loc[0] - m && x <= loc[0] + dock.width + m &&
            y >= loc[1] - m && y <= loc[1] + dock.height + m
    }

    private fun dockIndexAt(x: Float, y: Float): Int {
        val vertical = dockVertical()
        val loc = IntArray(2)
        var idx = 0
        for (i in 0 until dock.childCount) {
            val c = dock.getChildAt(i)
            c.getLocationInWindow(loc)
            val center = if (vertical) loc[1] + c.height / 2f else loc[0] + c.width / 2f
            val pos = if (vertical) y else x
            if (pos > center) idx++
        }
        return idx
    }

    override fun onDragMove(x: Float, y: Float) {
        val g = ghost ?: return
        val hl = highlight ?: return
        val half = g.layoutParams.width / 2f
        g.translationX = x - half
        g.translationY = y - half

        val over = isOverDock(x, y)
        if (over != dockHover) {
            dockHover = over
            val s = if (over) 1.08f else 1f
            dock.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
        if (over) {
            hl.visibility = View.INVISIBLE
        } else {
            val xAbs = scroller.scrollX + x
            val page = (xAbs / mW).toInt().coerceIn(0, max(0, scroller.pageCount - 1))
            val xIn = xAbs - page * mW
            val col = ((xIn - mPadL) / mCw).toInt().coerceIn(0, mCols - 1)
            val row = ((y - mPadT) / mCh).toInt().coerceIn(0, mRows - 1)
            hoverPage = page
            hoverCell = row * mCols + col
            hl.translationX = (page * mW - scroller.scrollX + mPadL + col * mCw + dp(6)).toFloat()
            hl.translationY = (mPadT + row * mCh + dp(6)).toFloat()
            hl.visibility = View.VISIBLE
        }

        // Hold near a side edge to flip pages.
        val m = dp(36)
        val dir = if (x < m) -1 else if (x > root.width - m) 1 else 0
        if (dir != edgeDir) {
            edgeDir = dir
            ui.removeCallbacks(edgeFlip)
            if (dir != 0) ui.postDelayed(edgeFlip, 450)
        }
    }

    override fun onDragEnd(x: Float, y: Float, cancelled: Boolean) {
        val st = drag ?: return
        ui.removeCallbacks(edgeFlip)
        edgeDir = 0
        val overDock = isOverDock(x, y)
        val dockIdx = dockIndexAt(x, y)
        val page = hoverPage
        val cell = hoverCell

        ghost?.let { dragLayer.removeView(it) }
        ghost = null
        highlight?.let { dragLayer.removeView(it) }
        highlight = null
        dock.animate().cancel()
        dock.scaleX = 1f
        dock.scaleY = 1f
        dockHover = false
        drag = null

        if (!cancelled) {
            if (overDock) dropOnDock(st.entry, dockIdx) else dropOnHome(st.entry, page, cell)
            compactPages()
            data.home.firstOrNull { it.key == st.entry.key }?.let { currentPage = it.page }
            store.save(data)
        }
        rebuildHome()
        buildDock()
    }

    private fun dropOnDock(e: AppEntry, idx: Int) {
        val wasInDock = data.dock.contains(e.key)
        if (!wasInDock && data.dock.size >= MAX_DOCK) {
            toast("Dock is full. Remove an app first.")
            return
        }
        data.home.removeAll { it.key == e.key }
        data.dock.remove(e.key)
        data.dock.add(idx.coerceIn(0, data.dock.size), e.key)
    }

    private fun dropOnHome(e: AppEntry, page: Int, cell: Int) {
        val cap = capacity()
        val existing = data.home.firstOrNull { it.key == e.key }
        data.dock.remove(e.key)
        if (existing != null) data.home.remove(existing)
        val occupant = data.home.firstOrNull { it.page == page && it.cell == cell }
        if (occupant != null) {
            if (existing != null) {
                // Swap places.
                occupant.page = existing.page
                occupant.cell = existing.cell
            } else {
                // Push the occupant to the next free cell.
                val used = usedSlots(occupant)
                used.add(page * cap + cell)
                val free = findFree(page * cap + cell + 1, used)
                occupant.page = free / cap
                occupant.cell = free % cap
            }
        }
        data.home.add(HomeItem(e.key, page, cell))
    }

    // ---------- Drawer ----------

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    private fun openDrawer() {
        drawerOpen = true
        if (drawer.visibility != View.VISIBLE) {
            drawer.translationY = root.height.toFloat()
            drawer.visibility = View.VISIBLE
        }
        drawer.animate()
            .translationY(0f)
            .setDuration(280)
            .setInterpolator(DecelerateInterpolator(1.5f))
            .start()
    }

    private fun closeDrawer() {
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        drawer.animate()
            .translationY(root.height.toFloat())
            .setDuration(240)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                if (!drawerOpen) {
                    drawer.visibility = View.GONE
                    drawerGrid.setSelection(0)
                }
            }
            .start()
    }

    override fun shouldIntercept(dy: Float): Boolean {
        return if (drawerOpen) dy > 0 && !drawerGrid.canScrollVertically(-1) else dy < 0
    }

    override fun onDragStart() {
        drawer.animate().cancel()
        hideKeyboard()
        if (drawer.visibility != View.VISIBLE) {
            drawer.translationY = root.height.toFloat()
            drawer.visibility = View.VISIBLE
        }
        dragBase = drawer.translationY
    }

    override fun onDrag(dy: Float) {
        drawer.translationY = (dragBase + dy).coerceIn(0f, root.height.toFloat())
    }

    override fun onRelease(dy: Float, vy: Float) {
        val h = root.height.toFloat()
        val open = when {
            vy < -1000f -> true
            vy > 1000f -> false
            else -> drawer.translationY < h * 0.5f
        }
        if (open) openDrawer() else closeDrawer()
    }

    // ---------- Lifecycle ----------

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer()
        currentPage = 0
        scroller.smoothScrollTo(0, 0)
    }

    // A launcher must not close on Back.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            search.text.isNotEmpty() -> search.setText("")
            drawerOpen -> closeDrawer()
            else -> { }
        }
    }

    override fun onDestroy() {
        launcherApps.unregisterCallback(callback)
        ui.removeCallbacksAndMessages(null)
        worker.shutdown()
        super.onDestroy()
    }

    private inner class DrawerAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cell = convertView ?: buildCell(this@MainActivity, 56)
            bindCell(cell, shown[position])
            return cell
        }
    }
}
