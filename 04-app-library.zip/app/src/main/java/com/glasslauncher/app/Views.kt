package com.glasslauncher.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt

fun buildCell(ctx: Context, iconDp: Int): LinearLayout {
    val d = ctx.resources.displayMetrics.density
    val cell = LinearLayout(ctx)
    cell.orientation = LinearLayout.VERTICAL
    cell.gravity = Gravity.CENTER

    val icon = ImageView(ctx)
    icon.layoutParams = LinearLayout.LayoutParams((iconDp * d).toInt(), (iconDp * d).toInt())
    cell.addView(icon)

    val label = TextView(ctx)
    label.setTextColor(Color.WHITE)
    label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
    label.maxLines = 1
    label.ellipsize = TextUtils.TruncateAt.END
    label.gravity = Gravity.CENTER
    label.setShadowLayer(4f, 0f, 1f, 0x66000000)
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = (6 * d).toInt()
    label.layoutParams = lp
    cell.addView(label)
    return cell
}

fun bindCell(cell: View, e: AppEntry) {
    val c = cell as LinearLayout
    (c.getChildAt(0) as ImageView).setImageDrawable(e.icon)
    (c.getChildAt(1) as TextView).text = e.label
}

// Places each child at an explicit cell index in a fixed cols x rows grid.
class IconGrid(context: Context, private val cols: Int, private val rows: Int) : ViewGroup(context) {
    private val cells = ArrayList<Int>()

    fun addCell(v: View, cell: Int) {
        cells.add(cell)
        addView(v)
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)
        val cw = max(1, (w - paddingLeft - paddingRight) / cols)
        val ch = max(1, (h - paddingTop - paddingBottom) / rows)
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = max(1, (width - paddingLeft - paddingRight) / cols)
        val ch = max(1, (height - paddingTop - paddingBottom) / rows)
        for (i in 0 until childCount) {
            val c = cells[i]
            val x = paddingLeft + (c % cols) * cw
            val y = paddingTop + (c / cols) * ch
            getChildAt(i).layout(x, y, x + cw, y + ch)
        }
    }
}

// Horizontal pager that always snaps to a whole page.
class PageScroller(context: Context) : HorizontalScrollView(context) {
    val content = LinearLayout(context)
    var pageCount = 1
    var onPosition: ((Float) -> Unit)? = null
    var onSettled: ((Int) -> Unit)? = null
    private var flingV = 0

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        content.orientation = LinearLayout.HORIZONTAL
        addView(
            content,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
    }

    override fun fling(velocityX: Int) {
        flingV = velocityX
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val handled = super.onTouchEvent(ev)
        val a = ev.actionMasked
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) snap()
        return handled
    }

    private fun snap() {
        val w = width
        if (w <= 0) return
        val cur = scrollX.toFloat() / w
        var target = when {
            flingV > 600 -> ceil(cur).toInt()
            flingV < -600 -> floor(cur).toInt()
            else -> cur.roundToInt()
        }
        flingV = 0
        target = target.coerceIn(0, max(0, pageCount - 1))
        smoothScrollTo(target * w, 0)
        onSettled?.invoke(target)
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        if (width > 0) onPosition?.invoke(l.toFloat() / width)
    }
}

class DotsView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    var count: Int = 1
        set(v) {
            field = v
            visibility = if (v > 1) View.VISIBLE else View.INVISIBLE
            requestLayout()
            invalidate()
        }

    var position: Float = 0f
        set(v) {
            field = v
            invalidate()
        }

    init {
        visibility = View.INVISIBLE
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension((count * 14 * d).toInt() + (8 * d).toInt(), (12 * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val gap = 14 * d
        val startX = (width - (count - 1) * gap) / 2f
        val active = position.roundToInt()
        for (i in 0 until count) {
            paint.color = if (i == active) Color.WHITE else 0x66FFFFFF
            canvas.drawCircle(startX + i * gap, height / 2f, 3 * d, paint)
        }
    }
}

// Root container: drawer swipe gestures plus long-press drag and drop.
class RootLayout(context: Context) : FrameLayout(context) {
    interface Gesture {
        fun shouldIntercept(dy: Float): Boolean
        fun onDragStart()
        fun onDrag(dy: Float)
        fun onRelease(dy: Float, vy: Float)
    }

    interface DragHost {
        fun onDragStart(x: Float, y: Float): Boolean
        fun onDragMove(x: Float, y: Float)
        fun onDragEnd(x: Float, y: Float, cancelled: Boolean)
        fun onArmedEnd(released: Boolean)
    }

    var gesture: Gesture? = null
    var dragHost: DragHost? = null
    val touchX: Float get() = lastX
    val touchY: Float get() = lastY

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var armX = 0f
    private var armY = 0f
    private var armed = false
    private var dragMode = false
    private var dragging = false
    private var tracker: VelocityTracker? = null
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    // Called by a long-press handler: the next finger movement turns into a drag.
    fun arm() {
        armed = true
        armX = lastX
        armY = lastY
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        lastX = ev.x
        lastY = ev.y
        val a = ev.actionMasked

        if (dragMode) {
            when (a) {
                MotionEvent.ACTION_MOVE -> dragHost?.onDragMove(ev.x, ev.y)
                MotionEvent.ACTION_UP -> {
                    dragMode = false
                    dragHost?.onDragEnd(ev.x, ev.y, false)
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragMode = false
                    dragHost?.onDragEnd(ev.x, ev.y, true)
                }
            }
            return true
        }

        if (armed) {
            if (a == MotionEvent.ACTION_MOVE) {
                if (abs(ev.x - armX) > slop * 2 || abs(ev.y - armY) > slop * 2) {
                    armed = false
                    val now = SystemClock.uptimeMillis()
                    val cancel = MotionEvent.obtain(now, now, MotionEvent.ACTION_CANCEL, ev.x, ev.y, 0)
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                    dragMode = dragHost?.onDragStart(ev.x, ev.y) == true
                    if (dragMode) dragHost?.onDragMove(ev.x, ev.y)
                    return true
                }
            } else if (a == MotionEvent.ACTION_UP) {
                armed = false
                dragHost?.onArmedEnd(true)
            } else if (a == MotionEvent.ACTION_CANCEL) {
                armed = false
                dragHost?.onArmedEnd(false)
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun tryStart(ev: MotionEvent): Boolean {
        if (armed || dragMode) return false
        val dx = ev.x - downX
        val dy = ev.y - downY
        if (abs(dy) > slop && abs(dy) > abs(dx) * 1.5f && gesture?.shouldIntercept(dy) == true) {
            dragging = true
            tracker = VelocityTracker.obtain()
            tracker?.addMovement(ev)
            gesture?.onDragStart()
            return true
        }
        return false
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && tryStart(ev)) return true
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val a = ev.actionMasked
        if (!dragging) {
            if (a == MotionEvent.ACTION_DOWN) {
                downX = ev.x
                downY = ev.y
            } else if (a == MotionEvent.ACTION_MOVE) {
                tryStart(ev)
            }
            return true
        }
        tracker?.addMovement(ev)
        when (a) {
            MotionEvent.ACTION_MOVE -> gesture?.onDrag(ev.y - downY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                tracker?.computeCurrentVelocity(1000)
                val vy = tracker?.yVelocity ?: 0f
                tracker?.recycle()
                tracker = null
                dragging = false
                gesture?.onRelease(ev.y - downY, vy)
            }
        }
        return true
    }
}
