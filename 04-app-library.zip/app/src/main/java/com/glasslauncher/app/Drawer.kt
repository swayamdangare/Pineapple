package com.glasslauncher.app

import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import kotlin.math.max

private val LETTERS: List<String> = ('A'..'Z').map { it.toString() } + "#"

// Sorts apps into groups. Own names, simple rules; the user can override any app.
object Categorizer {
    val ORDER = listOf(
        "Social", "Media", "Games", "Productivity", "Education",
        "Shopping", "Travel", "Finance", "Tools", "Other"
    )

    private val rules: List<Pair<String, List<String>>> = listOf(
        "Games" to listOf("game", "ludo", "pubg", "bgmi", "freefire", "free fire", "clash", "minecraft", "roblox", "chess", "candy"),
        "Social" to listOf("whatsapp", "telegram", "instagram", "facebook", "twitter", "snapchat", "discord", "linkedin", "reddit", "signal", "messenger", "threads", "pinterest", "sharechat"),
        "Finance" to listOf("gpay", "phonepe", "paytm", "bank", "upi", "wallet", "cred", "zerodha", "groww", "finance", "pay", "money", "insurance"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "meesho", "blinkit", "zepto", "swiggy", "zomato", "bigbasket", "ajio", "nykaa", "shop", "jiomart", "instamart"),
        "Travel" to listOf("maps", "uber", "ola ", "rapido", "irctc", "makemytrip", "goibibo", "redbus", "travel", "flight", "train", "navigation"),
        "Education" to listOf("allen", "examgoal", "byju", "unacademy", "physicswallah", "learn", "study", "classroom", "duolingo", "khan", "exam", "course", "school", "neet", "vedantu"),
        "Media" to listOf("youtube", "spotify", "netflix", "music", "video", "player", "camera", "gallery", "photos", "gaana", "jiosaavn", "hotstar", "radio", "podcast", "audio", "movie", "vlc"),
        "Productivity" to listOf("docs", "sheets", "slides", "drive", "office", "word", "excel", "powerpoint", "notes", "keep", "calendar", "mail", "outlook", "scan", "pdf", "notion", "zoom", "meet", "teams", "adobe", "todo", "tasks", "chatgpt", "claude", "gemini", "assistant"),
        "Tools" to listOf("calculator", "clock", "settings", "files", "file manager", "compass", "weather", "recorder", "torch", "flashlight", "security", "cleaner", "system", "android", "play services", "wellbeing", "contacts", "phone", "dialer", "browser", "chrome", "vault", "launcher", "downloads", "update", "backup", "manager", "translate")
    )

    fun categoryOf(e: AppEntry, prefs: PrefsStore): String {
        val custom = prefs.categoryOverride(e.key)
        if (custom != null) return custom
        val byApi: String? = when (e.category) {
            ApplicationInfo.CATEGORY_GAME -> "Games"
            ApplicationInfo.CATEGORY_AUDIO -> "Media"
            ApplicationInfo.CATEGORY_VIDEO -> "Media"
            ApplicationInfo.CATEGORY_IMAGE -> "Media"
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_NEWS -> "Media"
            ApplicationInfo.CATEGORY_MAPS -> "Travel"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
            else -> null
        }
        if (byApi != null) return byApi
        val text = (e.label + " " + e.component.packageName).lowercase()
        for (rule in rules) {
            for (w in rule.second) {
                if (text.contains(w)) return rule.first
            }
        }
        return "Other"
    }
}

class DrawerView(
    context: Context,
    private val prefs: PrefsStore,
    private val host: Host
) : FrameLayout(context) {

    interface Host {
        fun launch(e: AppEntry)
        fun longPress(view: View, e: AppEntry, items: List<Pair<String, () -> Unit>>)
        fun addToHome(e: AppEntry)
        fun addToDock(e: AppEntry)
        fun appInfo(e: AppEntry)
    }

    private class Tile(val title: String, val apps: List<AppEntry>)
    private class Row(val letter: String?, val app: AppEntry?)

    private val d = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d).toInt()

    private var apps: List<AppEntry> = emptyList()
    private var visibleApps: List<AppEntry> = emptyList()
    private var tiles: List<Tile> = emptyList()
    private var rows: List<Row> = emptyList()
    private var results: List<AppEntry> = emptyList()
    private var panelApps: List<AppEntry> = emptyList()
    private var query = ""
    private var gridMode = prefs.drawerGrid
    private var tileSide = dp(150)

    private val body = LinearLayout(context)
    private val topRow = LinearLayout(context)
    private val search = EditText(context)
    private val toggle = TextView(context)
    private val content = FrameLayout(context)
    private val tilesGrid = GridView(context)
    private val resultsGrid = GridView(context)
    private val listContainer = FrameLayout(context)
    private val listView = ListView(context)
    private val sidebar = LinearLayout(context)
    private val panel = FrameLayout(context)
    private val card = LinearLayout(context)
    private val panelTitle = TextView(context)
    private val panelGrid = GridView(context)

    private val tilesAdapter = TilesAdapter()
    private val letterAdapter = LetterAdapter()
    private val resultsAdapter = AppGridAdapter { results }
    private val panelAdapter = AppGridAdapter { panelApps }

    init {
        setBackgroundColor(Color.argb(242, 16, 16, 24))
        isClickable = true
        visibility = View.GONE

        body.orientation = LinearLayout.VERTICAL
        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.gravity = Gravity.CENTER_VERTICAL

        search.hint = "Search apps"
        search.setHintTextColor(Color.argb(153, 255, 255, 255))
        search.setTextColor(Color.WHITE)
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        search.isSingleLine = true
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.setPadding(dp(16), dp(10), dp(16), dp(10))
        search.background = GradientDrawable().apply {
            setColor(0x26FFFFFF)
            cornerRadius = dp(14).toFloat()
        }
        search.setOnEditorActionListener { _, _, _ ->
            hideKeyboard()
            true
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = (s?.toString() ?: "").trim()
                updateContent()
            }
        })
        topRow.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        toggle.text = if (gridMode) "List" else "Grid"
        toggle.setTextColor(Color.WHITE)
        toggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        toggle.gravity = Gravity.CENTER
        toggle.setPadding(dp(16), dp(10), dp(16), dp(10))
        toggle.background = GradientDrawable().apply {
            setColor(0x26FFFFFF)
            cornerRadius = dp(14).toFloat()
        }
        toggle.setOnClickListener {
            gridMode = !gridMode
            prefs.drawerGrid = gridMode
            toggle.text = if (gridMode) "List" else "Grid"
            updateContent()
        }
        val toggleLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        toggleLp.leftMargin = dp(10)
        topRow.addView(toggle, toggleLp)

        val rowLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        rowLp.bottomMargin = dp(12)
        body.addView(topRow, rowLp)

        // Category tiles
        tilesGrid.selector = ColorDrawable(Color.TRANSPARENT)
        tilesGrid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        tilesGrid.clipToPadding = false
        tilesGrid.isVerticalScrollBarEnabled = false
        tilesGrid.overScrollMode = View.OVER_SCROLL_NEVER
        tilesGrid.adapter = tilesAdapter
        tilesGrid.setOnItemClickListener { _, _, pos, _ -> openPanel(tiles[pos]) }
        content.addView(tilesGrid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Search results
        resultsGrid.selector = ColorDrawable(Color.TRANSPARENT)
        resultsGrid.verticalSpacing = dp(14)
        resultsGrid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        resultsGrid.clipToPadding = false
        resultsGrid.isVerticalScrollBarEnabled = false
        resultsGrid.overScrollMode = View.OVER_SCROLL_NEVER
        resultsGrid.adapter = resultsAdapter
        resultsGrid.setOnItemClickListener { _, _, pos, _ -> host.launch(results[pos]) }
        resultsGrid.setOnItemLongClickListener { _, view, pos, _ ->
            val e = results[pos]
            host.longPress(view, e, menuItems(e))
            true
        }
        content.addView(resultsGrid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // A-Z list
        listView.divider = null
        listView.dividerHeight = 0
        listView.selector = ColorDrawable(Color.TRANSPARENT)
        listView.clipToPadding = false
        listView.isVerticalScrollBarEnabled = false
        listView.overScrollMode = View.OVER_SCROLL_NEVER
        listView.adapter = letterAdapter
        listView.setOnItemClickListener { _, _, pos, _ ->
            val e = rows[pos].app
            if (e != null) host.launch(e)
        }
        listView.setOnItemLongClickListener { _, view, pos, _ ->
            val e = rows[pos].app
            if (e != null) {
                host.longPress(view, e, menuItems(e))
                true
            } else {
                false
            }
        }
        listContainer.addView(listView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        sidebar.orientation = LinearLayout.VERTICAL
        for (l in LETTERS) {
            val tv = TextView(context)
            tv.text = l
            tv.setTextColor(Color.argb(190, 255, 255, 255))
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            tv.gravity = Gravity.CENTER
            sidebar.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        sidebar.setOnTouchListener { v, ev ->
            val a = ev.actionMasked
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                v.parent.requestDisallowInterceptTouchEvent(true)
                val idx = ((ev.y / max(1, v.height)) * LETTERS.size).toInt().coerceIn(0, LETTERS.size - 1)
                jumpTo(idx)
            }
            true
        }
        listContainer.addView(sidebar, FrameLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.RIGHT))
        content.addView(listContainer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        body.addView(
            content,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        addView(body, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Category popup panel
        panel.setBackgroundColor(Color.argb(140, 0, 0, 0))
        panel.visibility = View.GONE
        panel.isClickable = true
        panel.setOnClickListener { closePanel() }

        card.orientation = LinearLayout.VERTICAL
        card.isClickable = true
        card.setPadding(dp(16), dp(16), dp(16), dp(12))
        card.background = GradientDrawable().apply {
            setColor(Color.argb(235, 38, 38, 50))
            cornerRadius = dp(28).toFloat()
        }
        panelTitle.setTextColor(Color.WHITE)
        panelTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        panelTitle.setPadding(dp(8), 0, 0, dp(12))
        card.addView(panelTitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        panelGrid.selector = ColorDrawable(Color.TRANSPARENT)
        panelGrid.verticalSpacing = dp(12)
        panelGrid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        panelGrid.isVerticalScrollBarEnabled = false
        panelGrid.overScrollMode = View.OVER_SCROLL_NEVER
        panelGrid.adapter = panelAdapter
        panelGrid.setOnItemClickListener { _, _, pos, _ -> host.launch(panelApps[pos]) }
        panelGrid.setOnItemLongClickListener { _, view, pos, _ ->
            val e = panelApps[pos]
            host.longPress(view, e, menuItems(e))
            true
        }
        card.addView(panelGrid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(
            card,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        updateContent()
    }

    // ---------- Public API ----------

    fun setApps(list: List<AppEntry>) {
        apps = list
        recompute()
    }

    fun refresh() {
        recompute()
    }

    fun setInsets(t: Int, b: Int, l: Int, r: Int) {
        body.setPadding(0, t + dp(16), 0, 0)
        val rlp = topRow.layoutParams as LinearLayout.LayoutParams
        rlp.leftMargin = l + dp(16)
        rlp.rightMargin = r + dp(16)
        topRow.layoutParams = rlp
        tilesGrid.setPadding(l + dp(16), dp(4), r + dp(16), b + dp(24))
        resultsGrid.setPadding(l + dp(12), dp(8), r + dp(12), b + dp(24))
        listView.setPadding(l + dp(8), 0, dp(32), b + dp(24))
        val slp = sidebar.layoutParams as FrameLayout.LayoutParams
        slp.rightMargin = r + dp(2)
        slp.topMargin = dp(6)
        slp.bottomMargin = b + dp(24)
        sidebar.layoutParams = slp
        val clp = card.layoutParams as FrameLayout.LayoutParams
        clp.setMargins(l + dp(20), t + dp(24), r + dp(20), b + dp(24))
        card.layoutParams = clp
        this.insetL = l
        this.insetR = r
        updateColumns()
    }

    private var insetL = 0
    private var insetR = 0

    fun updateColumns() {
        val dm = resources.displayMetrics
        val wDp = dm.widthPixels / d
        val tileCols = (wDp / 170f).toInt().coerceIn(2, 5)
        val gap = dp(16)
        tilesGrid.numColumns = tileCols
        tilesGrid.horizontalSpacing = gap
        tilesGrid.verticalSpacing = dp(10)
        tileSide = max(dp(80), (dm.widthPixels - insetL - insetR - dp(32) - gap * (tileCols - 1)) / tileCols)
        resultsGrid.numColumns = (wDp / 92f).toInt().coerceIn(4, 8)
        panelGrid.numColumns = ((wDp - 72f) / 84f).toInt().coerceIn(3, 6)
        tilesAdapter.notifyDataSetChanged()
    }

    fun hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    // Back closes the panel, then clears the search. Returns true if it handled Back.
    fun handleBack(): Boolean {
        if (panel.visibility == View.VISIBLE) {
            closePanel()
            return true
        }
        if (search.text.isNotEmpty()) {
            search.setText("")
            return true
        }
        return false
    }

    // True while a swipe-down should NOT close the drawer.
    fun canScrollUp(): Boolean {
        if (panel.visibility == View.VISIBLE) return true
        val v: View = when {
            query.isNotEmpty() -> resultsGrid
            gridMode -> tilesGrid
            else -> listView
        }
        return v.canScrollVertically(-1)
    }

    fun reset() {
        closePanelInstant()
        hideKeyboard()
        search.setText("")
        tilesGrid.setSelection(0)
        listView.setSelection(0)
        resultsGrid.setSelection(0)
    }

    // ---------- Data ----------

    private fun recompute() {
        visibleApps = apps.filter { !prefs.isHidden(it.key) }
        buildTiles()
        buildRows()
        tilesAdapter.notifyDataSetChanged()
        letterAdapter.notifyDataSetChanged()
        updateContent()
    }

    private fun buildTiles() {
        val t = ArrayList<Tile>()
        val bucket = prefs.bucketNow()
        val suggested = visibleApps
            .map { it to prefs.score(it.key, bucket) }
            .filter { it.second > 0L }
            .sortedByDescending { it.second }
            .take(8)
            .map { it.first }
        if (suggested.isNotEmpty()) t.add(Tile("Suggested", suggested))

        val recent = visibleApps
            .filter { prefs.lastUsed(it.key) > 0L }
            .sortedByDescending { prefs.lastUsed(it.key) }
            .take(12)
        if (recent.isNotEmpty()) t.add(Tile("Recently used", recent))

        val cutoff = System.currentTimeMillis() - 14L * 24L * 60L * 60L * 1000L
        val added = visibleApps
            .filter { it.installTime > cutoff }
            .sortedByDescending { it.installTime }
            .take(12)
        if (added.isNotEmpty()) t.add(Tile("Recently added", added))

        val byCat = visibleApps.groupBy { Categorizer.categoryOf(it, prefs) }
        for (c in Categorizer.ORDER) {
            val l = byCat[c]
            if (l != null && l.isNotEmpty()) t.add(Tile(c, l))
        }
        val hidden = apps.filter { prefs.isHidden(it.key) }
        if (hidden.isNotEmpty()) t.add(Tile("Hidden", hidden))
        tiles = t
    }

    private fun letterOf(label: String): String {
        val c = label.trim().firstOrNull()?.uppercaseChar() ?: return "#"
        return if (c in 'A'..'Z') c.toString() else "#"
    }

    private fun buildRows() {
        val groups = visibleApps.groupBy { letterOf(it.label) }
        val r = ArrayList<Row>()
        for (l in LETTERS) {
            val g = groups[l] ?: continue
            r.add(Row(l, null))
            for (e in g) r.add(Row(null, e))
        }
        rows = r
    }

    private fun updateContent() {
        val searching = query.isNotEmpty()
        if (searching) {
            results = visibleApps.filter { it.label.contains(query, ignoreCase = true) }
            resultsAdapter.notifyDataSetChanged()
        }
        tilesGrid.visibility = if (!searching && gridMode) View.VISIBLE else View.GONE
        listContainer.visibility = if (!searching && !gridMode) View.VISIBLE else View.GONE
        resultsGrid.visibility = if (searching) View.VISIBLE else View.GONE
    }

    private fun jumpTo(idx: Int) {
        var i = idx
        while (i < LETTERS.size) {
            val l = LETTERS[i]
            val pos = rows.indexOfFirst { it.letter == l }
            if (pos >= 0) {
                listView.setSelection(pos)
                return
            }
            i++
        }
        listView.setSelection(max(0, rows.size - 1))
    }

    // ---------- Menus and panel ----------

    private fun menuItems(e: AppEntry): List<Pair<String, () -> Unit>> {
        val hidden = prefs.isHidden(e.key)
        return listOf(
            "Add to Home Screen" to { host.addToHome(e) },
            "Add to Dock" to { host.addToDock(e) },
            (if (hidden) "Show in drawer" else "Hide from drawer") to {
                prefs.setHidden(e.key, !hidden)
                closePanel()
                recompute()
            },
            "Move to category" to { chooseCategory(e) },
            "App info" to { host.appInfo(e) }
        )
    }

    private fun chooseCategory(e: AppEntry) {
        val pm = PopupMenu(context, toggle)
        Categorizer.ORDER.forEachIndexed { i, c -> pm.menu.add(0, i, i, c) }
        pm.setOnMenuItemClickListener { m ->
            prefs.setCategory(e.key, Categorizer.ORDER[m.itemId])
            closePanel()
            recompute()
            true
        }
        pm.show()
    }

    private fun openPanel(tile: Tile) {
        panelApps = tile.apps
        panelTitle.text = tile.title
        panelAdapter.notifyDataSetChanged()
        panelGrid.setSelection(0)
        panel.animate().cancel()
        card.animate().cancel()
        panel.alpha = 0f
        panel.visibility = View.VISIBLE
        card.scaleX = 0.92f
        card.scaleY = 0.92f
        card.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
        panel.animate().alpha(1f).setDuration(180).start()
    }

    private fun closePanel() {
        if (panel.visibility != View.VISIBLE) return
        panel.animate().cancel()
        panel.animate().alpha(0f).setDuration(140).withEndAction {
            panel.visibility = View.GONE
        }.start()
    }

    private fun closePanelInstant() {
        panel.animate().cancel()
        card.animate().cancel()
        panel.visibility = View.GONE
    }

    // ---------- Adapters ----------

    private inner class AppGridAdapter(val source: () -> List<AppEntry>) : BaseAdapter() {
        override fun getCount(): Int = source().size
        override fun getItem(position: Int): Any = source()[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val c = convertView ?: buildCell(context, 56)
            bindCell(c, source()[position])
            return c
        }
    }

    private inner class TilesAdapter : BaseAdapter() {
        override fun getCount(): Int = tiles.size
        override fun getItem(position: Int): Any = tiles[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val root = (convertView as? LinearLayout) ?: makeTile()
            bindTile(root, tiles[position])
            return root
        }

        private fun makeTile(): LinearLayout {
            val root = LinearLayout(context)
            root.orientation = LinearLayout.VERTICAL
            val box = LinearLayout(context)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(6), dp(6), dp(6), dp(6))
            box.background = GradientDrawable().apply {
                setColor(0x33FFFFFF)
                cornerRadius = dp(24).toFloat()
            }
            for (r in 0 until 2) {
                val row = LinearLayout(context)
                row.orientation = LinearLayout.HORIZONTAL
                for (c in 0 until 2) {
                    val iv = ImageView(context)
                    iv.scaleType = ImageView.ScaleType.FIT_CENTER
                    iv.setPadding(dp(6), dp(6), dp(6), dp(6))
                    row.addView(iv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                }
                box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            }
            root.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            val label = TextView(context)
            label.setTextColor(Color.WHITE)
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            label.gravity = Gravity.CENTER
            label.maxLines = 1
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6)
            root.addView(label, lp)
            return root
        }

        private fun bindTile(root: LinearLayout, tile: Tile) {
            root.layoutParams = AbsListView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                tileSide + dp(34)
            )
            val box = root.getChildAt(0) as LinearLayout
            for (i in 0 until 4) {
                val row = box.getChildAt(i / 2) as LinearLayout
                val iv = row.getChildAt(i % 2) as ImageView
                val e = tile.apps.getOrNull(i)
                if (e == null) {
                    iv.setImageDrawable(null)
                    iv.setOnClickListener(null)
                    iv.setOnLongClickListener(null)
                    iv.isClickable = false
                    iv.isLongClickable = false
                } else {
                    iv.setImageDrawable(e.icon)
                    iv.setOnClickListener { host.launch(e) }
                    iv.setOnLongClickListener {
                        host.longPress(iv, e, menuItems(e))
                        true
                    }
                }
            }
            (root.getChildAt(1) as TextView).text = tile.title
        }
    }

    private inner class LetterAdapter : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getViewTypeCount(): Int = 2
        override fun getItemViewType(position: Int): Int = if (rows[position].app == null) 0 else 1
        override fun isEnabled(position: Int): Boolean = rows[position].app != null
        override fun areAllItemsEnabled(): Boolean = false

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val r = rows[position]
            val e = r.app
            if (e == null) {
                val tv = (convertView as? TextView) ?: TextView(context).apply {
                    setTextColor(Color.argb(200, 255, 255, 255))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                    setPadding(dp(16), dp(14), 0, dp(4))
                }
                tv.text = r.letter
                return tv
            }
            val row = (convertView as? LinearLayout) ?: makeRow()
            (row.getChildAt(0) as ImageView).setImageDrawable(e.icon)
            (row.getChildAt(1) as TextView).text = e.label
            return row
        }

        private fun makeRow(): LinearLayout {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(6), dp(8), dp(6))
            val iv = ImageView(context)
            row.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)))
            val tv = TextView(context)
            tv.setTextColor(Color.WHITE)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            tv.maxLines = 1
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.leftMargin = dp(16)
            row.addView(tv, lp)
            return row
        }
    }
}
