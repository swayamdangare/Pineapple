package com.glasslauncher.app

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.UserHandle
import org.json.JSONArray
import org.json.JSONObject

class AppEntry(
    val label: String,
    val icon: Drawable,
    val component: ComponentName,
    val user: UserHandle,
    val installTime: Long = 0L,
    val category: Int = -1
) {
    val key: String = component.flattenToString()
    fun newIcon(): Drawable = icon.constantState?.newDrawable()?.mutate() ?: icon
}

// One icon on a Home page. cell is an index 0..capacity-1 (row-major).
class HomeItem(val key: String, var page: Int, var cell: Int)

class LayoutData {
    val home = ArrayList<HomeItem>()
    val dock = ArrayList<String>()
}

class LayoutStore(context: Context) {
    private val prefs = context.getSharedPreferences("layout", Context.MODE_PRIVATE)

    fun load(capacity: Int): LayoutData? {
        val raw2 = prefs.getString("layout_v2", null)
        if (raw2 != null) {
            try {
                val o = JSONObject(raw2)
                val l = LayoutData()
                val h = o.getJSONArray("home")
                for (i in 0 until h.length()) {
                    val x = h.getJSONObject(i)
                    l.home.add(HomeItem(x.getString("k"), x.getInt("p"), x.getInt("c")))
                }
                val d = o.getJSONArray("dock")
                for (i in 0 until d.length()) l.dock.add(d.getString(i))
                return l
            } catch (e: Exception) {
                // fall through to older format
            }
        }
        val raw1 = prefs.getString("layout_v1", null) ?: return null
        return try {
            val o = JSONObject(raw1)
            val l = LayoutData()
            val h = o.getJSONArray("home")
            for (i in 0 until h.length()) {
                l.home.add(HomeItem(h.getString(i), i / capacity, i % capacity))
            }
            val d = o.getJSONArray("dock")
            for (i in 0 until d.length()) l.dock.add(d.getString(i))
            l
        } catch (e: Exception) {
            null
        }
    }

    fun save(l: LayoutData) {
        val o = JSONObject()
        o.put("v", 2)
        val h = JSONArray()
        for (item in l.home) {
            val x = JSONObject()
            x.put("k", item.key)
            x.put("p", item.page)
            x.put("c", item.cell)
            h.put(x)
        }
        o.put("home", h)
        o.put("dock", JSONArray(l.dock))
        prefs.edit().putString("layout_v2", o.toString()).apply()
    }
}

// Drawer preferences: hidden apps, category overrides, usage log, view mode, wallpaper flag.
class PrefsStore(context: Context) {
    private val sp = context.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)
    private val hidden = HashSet<String>()
    private val cats = HashMap<String, String>()
    // usage[key] = [total, bucket0, bucket1, bucket2, bucket3, lastUsedMillis]
    private val usage = HashMap<String, LongArray>()
    // trans[a][b] = how often app b was opened right after app a
    private val trans = HashMap<String, HashMap<String, Int>>()
    private val customCats = ArrayList<String>()

    var lastLaunched: String? = sp.getString("last", null)
        private set

    var drawerGrid: Boolean = sp.getBoolean("drawer_grid", true)
        set(v) {
            field = v
            sp.edit().putBoolean("drawer_grid", v).apply()
        }

    var customWallpaper: Boolean = sp.getBoolean("custom_wallpaper", false)
        set(v) {
            field = v
            sp.edit().putBoolean("custom_wallpaper", v).apply()
        }

    var themeMode: Int = sp.getInt("theme_mode", 0)   // 0 auto, 1 light, 2 dark
        set(v) {
            field = v
            sp.edit().putInt("theme_mode", v).apply()
        }

    var profile: Int = sp.getInt("profile", -1)       // -1 = pick by device, 0 efficient, 1 balanced, 2 premium
        set(v) {
            field = v
            sp.edit().putInt("profile", v).apply()
        }

    var glassTransparency: Int = sp.getInt("glass_transparency", 50)
        set(v) {
            field = v
            sp.edit().putInt("glass_transparency", v).apply()
        }

    var blurStrength: Int = sp.getInt("blur_strength", 60)
        set(v) {
            field = v
            sp.edit().putInt("blur_strength", v).apply()
        }

    var cornerScale: Int = sp.getInt("corner_scale", 50)
        set(v) {
            field = v
            sp.edit().putInt("corner_scale", v).apply()
        }

    init {
        val h = sp.getStringSet("hidden", null)
        if (h != null) hidden.addAll(h)
        try {
            val o = JSONObject(sp.getString("cats", "{}") ?: "{}")
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                cats[k] = o.getString(k)
            }
        } catch (e: Exception) {
        }
        try {
            val o = JSONObject(sp.getString("usage", "{}") ?: "{}")
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val arr = o.getJSONArray(k)
                val a = LongArray(6)
                for (i in 0 until minOf(6, arr.length())) a[i] = arr.getLong(i)
                usage[k] = a
            }
        } catch (e: Exception) {
        }
        try {
            val o = JSONObject(sp.getString("trans", "{}") ?: "{}")
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val inner = o.getJSONObject(k)
                val m = HashMap<String, Int>()
                val ks2 = inner.keys()
                while (ks2.hasNext()) {
                    val k2 = ks2.next()
                    m[k2] = inner.getInt(k2)
                }
                trans[k] = m
            }
        } catch (e: Exception) {
        }
        try {
            val arr = JSONArray(sp.getString("custom_cats", "[]") ?: "[]")
            for (i in 0 until arr.length()) customCats.add(arr.getString(i))
        } catch (e: Exception) {
        }
    }

    fun isHidden(key: String): Boolean = hidden.contains(key)

    fun setHidden(key: String, value: Boolean) {
        if (value) hidden.add(key) else hidden.remove(key)
        sp.edit().putStringSet("hidden", HashSet(hidden)).apply()
    }

    fun categoryOverride(key: String): String? = cats[key]

    private fun saveCats() {
        val o = JSONObject()
        for ((k, v) in cats) o.put(k, v)
        sp.edit().putString("cats", o.toString()).apply()
    }

    private fun saveCustom() {
        val arr = JSONArray()
        for (c in customCats) arr.put(c)
        sp.edit().putString("custom_cats", arr.toString()).apply()
    }

    fun setCategory(key: String, category: String) {
        cats[key] = category
        saveCats()
    }

    fun clearCategory(key: String) {
        cats.remove(key)
        saveCats()
    }

    fun customCategories(): List<String> = customCats

    fun addCategory(name: String) {
        if (!customCats.contains(name)) {
            customCats.add(name)
            saveCustom()
        }
    }

    fun renameCategory(old: String, name: String) {
        val i = customCats.indexOf(old)
        if (i >= 0) customCats[i] = name
        val keys = cats.filterValues { it == old }.keys.toList()
        for (k in keys) cats[k] = name
        saveCustom()
        saveCats()
    }

    fun deleteCategory(name: String) {
        customCats.remove(name)
        val keys = cats.filterValues { it == name }.keys.toList()
        for (k in keys) cats.remove(k)
        saveCustom()
        saveCats()
    }

    // 0 morning, 1 afternoon, 2 evening, 3 night
    fun bucketNow(): Int {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when {
            h in 5..10 -> 0
            h in 11..16 -> 1
            h in 17..21 -> 2
            else -> 3
        }
    }

    fun recordLaunch(key: String) {
        val a = usage.getOrPut(key) { LongArray(6) }
        a[0] = a[0] + 1
        val b = 1 + bucketNow()
        a[b] = a[b] + 1
        a[5] = System.currentTimeMillis()

        val prev = lastLaunched
        if (prev != null && prev != key) {
            val m = trans.getOrPut(prev) { HashMap() }
            m[key] = (m[key] ?: 0) + 1
            if (m.size > 8) {
                var minKey: String? = null
                var minVal = Int.MAX_VALUE
                for ((k, v) in m) {
                    if (k != key && v < minVal) {
                        minVal = v
                        minKey = k
                    }
                }
                if (minKey != null) m.remove(minKey)
            }
        }
        lastLaunched = key

        val uo = JSONObject()
        for ((k, v) in usage) {
            val arr = JSONArray()
            for (x in v) arr.put(x)
            uo.put(k, arr)
        }
        val to = JSONObject()
        for ((k, m) in trans) {
            val inner = JSONObject()
            for ((k2, v) in m) inner.put(k2, v)
            to.put(k, inner)
        }
        sp.edit()
            .putString("usage", uo.toString())
            .putString("trans", to.toString())
            .putString("last", key)
            .apply()
    }

    // How often an app is opened at this time of day (for tile ordering).
    fun score(key: String, bucket: Int): Long {
        val a = usage[key] ?: return 0L
        return a[1 + bucket] * 3 + a[0]
    }

    // Suggestion = time-of-day habit + overall use + "usually opened after the last app".
    fun suggestScore(key: String, bucket: Int, last: String?): Long {
        var s = score(key, bucket)
        if (last != null) s += (trans[last]?.get(key) ?: 0) * 5L
        return s
    }

    fun lastUsed(key: String): Long = usage[key]?.get(5) ?: 0L
}
