package com.glasslauncher.app

import android.app.ActivityManager
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

// Shared look settings. Everything glass-like reads from here.
object Glass {
    const val EFFICIENT = 0
    const val BALANCED = 1
    const val PREMIUM = 2

    var dark = true
    var profile = BALANCED
    var transparency = 50   // 0 = frosted, 100 = clear
    var blurStrength = 60
    var corner = 50
    var version = 0         // bumped when settings change so drawables rebuild
    var blur: Bitmap? = null

    fun configure(ctx: Context, prefs: PrefsStore) {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        dark = when (prefs.themeMode) {
            1 -> false
            2 -> true
            else -> night
        }
        var p = prefs.profile
        if (p < 0) {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            p = if (am.isLowRamDevice) EFFICIENT else BALANCED
        }
        profile = p
        transparency = prefs.glassTransparency
        blurStrength = prefs.blurStrength
        corner = prefs.cornerScale
        version++
    }

    val text: Int get() = if (dark) Color.WHITE else Color.rgb(20, 22, 32)

    fun textA(alpha: Int): Int {
        val t = text
        return Color.argb(alpha, Color.red(t), Color.green(t), Color.blue(t))
    }

    val fill: Int get() = if (dark) Color.argb(46, 255, 255, 255) else Color.argb(38, 0, 0, 0)
    val line: Int get() = if (dark) Color.argb(36, 255, 255, 255) else Color.argb(36, 0, 0, 0)

    fun radius(dp: Float, density: Float): Float = dp * density * (0.6f + 0.8f * corner / 100f)

    fun tintAlpha(hasBackdrop: Boolean): Float {
        val a = 0.80f - 0.50f * transparency / 100f
        return if (hasBackdrop) a else min(0.92f, a + 0.12f)
    }

    fun satBoost(): Float = if (profile == PREMIUM) 1.35f else 1.12f
}

// A frosted-glass surface: pre-blurred wallpaper behind, tint, soft sheen and a bright edge.
// No live blur: the blurred wallpaper is computed once and only drawn.
class GlassDrawable(
    private val view: View,
    private val radiusDp: Float,
    private val tint: Int? = null,
    private val backdrop: Boolean = true,
    private val strength: Float = 1f
) : Drawable() {
    private val density = view.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()
    private val loc = IntArray(2)
    private var satFilter: ColorMatrixColorFilter? = null
    private var satValue = -1f
    private var builtW = 0
    private var builtH = 0
    private var builtVersion = -1

    init {
        edgePaint.style = Paint.Style.STROKE
        edgePaint.strokeWidth = density
        paint.isFilterBitmap = true
    }

    private fun build(w: Float, h: Float) {
        val sheenA = if (Glass.profile == Glass.PREMIUM) 64 else 38
        sheenPaint.shader = LinearGradient(
            0f, 0f, w, h,
            Color.argb(sheenA, 255, 255, 255), Color.argb(0, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        val colors: IntArray
        if (Glass.profile == Glass.EFFICIENT) {
            colors = intArrayOf(Glass.line, Glass.line, Glass.line)
        } else if (Glass.dark) {
            colors = intArrayOf(Color.argb(190, 255, 255, 255), Color.argb(22, 255, 255, 255), Color.argb(90, 255, 255, 255))
        } else {
            colors = intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(20, 0, 0, 0), Color.argb(44, 0, 0, 0))
        }
        edgePaint.shader = LinearGradient(0f, 0f, w, h, colors, floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        if (builtW != b.width() || builtH != b.height() || builtVersion != Glass.version) {
            build(w, h)
            builtW = b.width()
            builtH = b.height()
            builtVersion = Glass.version
        }
        val r = if (radiusDp <= 0f) 0f else Glass.radius(radiusDp, density)
        rect.set(0f, 0f, w, h)

        canvas.save()
        if (r > 0f) {
            clip.reset()
            clip.addRoundRect(rect, r, r, Path.Direction.CW)
            canvas.clipPath(clip)
        }

        val bmp = Glass.blur
        val rv = view.rootView
        val hasBackdrop = backdrop && bmp != null && Glass.profile != Glass.EFFICIENT && rv.width > 0
        if (hasBackdrop && bmp != null) {
            view.getLocationInWindow(loc)
            val sx = rv.width / bmp.width.toFloat()
            val sy = rv.height / bmp.height.toFloat()
            val sat = Glass.satBoost()
            if (sat != satValue) {
                satValue = sat
                val cm = ColorMatrix()
                cm.setSaturation(sat)
                satFilter = ColorMatrixColorFilter(cm)
            }
            paint.colorFilter = satFilter
            canvas.save()
            canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
            canvas.scale(sx, sy)
            canvas.drawBitmap(bmp, 0f, 0f, paint)
            canvas.restore()
            paint.colorFilter = null
        }

        val base = tint ?: if (Glass.dark) Color.rgb(16, 18, 28) else Color.WHITE
        var a = Glass.tintAlpha(hasBackdrop) * strength
        if (tint != null) a = (0.30f + 0.18f * (1f - Glass.transparency / 100f)) * strength
        paint.style = Paint.Style.FILL
        paint.color = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(base), Color.green(base), Color.blue(base))
        canvas.drawRect(rect, paint)
        canvas.drawRect(rect, sheenPaint)
        canvas.restore()

        val inset = density * 0.5f
        val er = max(0f, r - inset)
        canvas.drawRoundRect(inset, inset, w - inset, h - inset, er, er, edgePaint)
    }

    override fun getOutline(outline: Outline) {
        val b = bounds
        val r = if (radiusDp <= 0f) 0f else Glass.radius(radiusDp, density)
        outline.setRoundRect(b.left, b.top, b.right, b.bottom, r)
        outline.alpha = if (Glass.profile == Glass.EFFICIENT) 0f else 1f
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

// Small, cheap blur: shrink the wallpaper, then box-blur three times.
object Blur {
    fun make(src: Bitmap, strength: Int): Bitmap {
        val w = 180
        val h = max(1, (src.height * (w / src.width.toFloat())).toInt())
        val scaled = Bitmap.createScaledBitmap(src, w, h, true)
        val bmp = scaled.copy(Bitmap.Config.ARGB_8888, true) ?: scaled
        val r = 1 + strength * 7 / 100
        val a = IntArray(w * h)
        val b = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        for (i in 0 until 3) {
            blurH(a, b, w, h, r)
            blurV(b, a, w, h, r)
        }
        bmp.setPixels(a, 0, w, 0, 0, w, h)
        return bmp
    }

    private fun blurH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = src[row + i.coerceIn(0, w - 1)]
                sr += (p shr 16) and 0xFF
                sg += (p shr 8) and 0xFF
                sb += p and 0xFF
            }
            for (x in 0 until w) {
                dst[row + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[row + min(w - 1, x + r + 1)]
                val sub = src[row + max(0, x - r)]
                sr += ((add shr 16) and 0xFF) - ((sub shr 16) and 0xFF)
                sg += ((add shr 8) and 0xFF) - ((sub shr 8) and 0xFF)
                sb += (add and 0xFF) - (sub and 0xFF)
            }
        }
    }

    private fun blurV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = src[i.coerceIn(0, h - 1) * w + x]
                sr += (p shr 16) and 0xFF
                sg += (p shr 8) and 0xFF
                sb += p and 0xFF
            }
            for (y in 0 until h) {
                dst[y * w + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[min(h - 1, y + r + 1) * w + x]
                val sub = src[max(0, y - r) * w + x]
                sr += ((add shr 16) and 0xFF) - ((sub shr 16) and 0xFF)
                sg += ((add shr 8) and 0xFF) - ((sub shr 8) and 0xFF)
                sb += (add and 0xFF) - (sub and 0xFF)
            }
        }
    }
}

// Built-in wallpapers drawn in code, so glass always has something to blur.
object Wallpapers {
    val NAMES = listOf("Aurora", "Dusk", "Graphite", "Sky")

    fun make(style: Int, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val top: Int
        val bottom: Int
        val blobs: List<Pair<FloatArray, Int>>
        when (style) {
            0 -> {
                top = Color.rgb(8, 12, 36)
                bottom = Color.rgb(34, 10, 64)
                blobs = listOf(
                    floatArrayOf(0.2f, 0.2f, 0.7f) to Color.rgb(0, 200, 180),
                    floatArrayOf(0.85f, 0.4f, 0.65f) to Color.rgb(140, 80, 255),
                    floatArrayOf(0.35f, 0.88f, 0.7f) to Color.rgb(255, 90, 150)
                )
            }
            1 -> {
                top = Color.rgb(28, 18, 50)
                bottom = Color.rgb(110, 44, 74)
                blobs = listOf(
                    floatArrayOf(0.25f, 0.25f, 0.7f) to Color.rgb(120, 70, 210),
                    floatArrayOf(0.8f, 0.85f, 0.75f) to Color.rgb(255, 140, 60),
                    floatArrayOf(0.9f, 0.2f, 0.5f) to Color.rgb(255, 90, 120)
                )
            }
            2 -> {
                top = Color.rgb(18, 20, 24)
                bottom = Color.rgb(48, 52, 60)
                blobs = listOf(
                    floatArrayOf(0.25f, 0.3f, 0.7f) to Color.rgb(90, 110, 145),
                    floatArrayOf(0.8f, 0.75f, 0.7f) to Color.rgb(70, 80, 100),
                    floatArrayOf(0.5f, 0.05f, 0.5f) to Color.rgb(120, 130, 150)
                )
            }
            else -> {
                top = Color.rgb(170, 210, 255)
                bottom = Color.rgb(236, 245, 255)
                blobs = listOf(
                    floatArrayOf(0.2f, 0.2f, 0.7f) to Color.rgb(255, 255, 255),
                    floatArrayOf(0.85f, 0.55f, 0.65f) to Color.rgb(255, 200, 225),
                    floatArrayOf(0.3f, 0.9f, 0.7f) to Color.rgb(255, 232, 170)
                )
            }
        }
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        for (blob in blobs) {
            val col = blob.second
            val rad = blob.first[2] * max(w, h)
            p.shader = RadialGradient(
                blob.first[0] * w, blob.first[1] * h, rad,
                Color.argb(190, Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }
        return bmp
    }
}

// Bottom sheet with the look settings.
class AppearanceSheet(
    context: Context,
    private val prefs: PrefsStore,
    private val host: Host
) : FrameLayout(context) {

    interface Host {
        fun onThemeOrProfileChanged()
        fun onGlassLive()
        fun onBlurRegenerate()
        fun onPickPhoto()
        fun onBuiltinWallpaper(style: Int)
        fun onSystemWallpaper()
    }

    private val d = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * d).toInt()

    private val scrim = View(context)
    private val card = FrameLayout(context)
    private val scroll = ScrollView(context)
    private val content = LinearLayout(context)
    private val hint = TextView(context)
    private val cardLp = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        Gravity.BOTTOM
    )

    var isOpen = false
        private set

    init {
        visibility = View.GONE
        scrim.setBackgroundColor(Color.argb(110, 0, 0, 0))
        scrim.setOnClickListener { close() }
        addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        card.background = GlassDrawable(card, 28f, null, true, 1.2f)
        card.elevation = dp(16).toFloat()
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(20), dp(18), dp(20), dp(22))
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        card.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        cardLp.setMargins(dp(12), dp(48), dp(12), dp(12))
        addView(card, cardLp)
        buildContent()
    }

    fun setInsets(t: Int, b: Int, l: Int, r: Int) {
        cardLp.setMargins(l + dp(12), t + dp(48), r + dp(12), b + dp(12))
        card.layoutParams = cardLp
    }

    fun refreshGlass() {
        card.invalidate()
    }

    fun open() {
        hint.text = if (prefs.customWallpaper) "Wallpaper" else "Glass blur needs a launcher wallpaper. Pick one below."
        isOpen = true
        card.animate().cancel()
        scrim.animate().cancel()
        visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(200).start()
        card.translationY = dp(420).toFloat()
        card.animate().translationY(0f).setDuration(300).setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    fun close() {
        if (!isOpen) return
        isOpen = false
        scrim.animate().alpha(0f).setDuration(180).start()
        card.animate().translationY(dp(420).toFloat()).setDuration(220).withEndAction {
            if (!isOpen) visibility = View.GONE
        }.start()
    }

    // ---------- Content ----------

    private fun label(text: String): TextView {
        val tv = TextView(context)
        tv.text = text
        tv.setTextColor(Glass.textA(170))
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        tv.setPadding(dp(2), dp(16), 0, dp(6))
        return tv
    }

    private fun buildContent() {
        val title = TextView(context)
        title.text = "Appearance"
        title.setTextColor(Glass.text)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        content.addView(title)

        content.addView(label("Theme"))
        content.addView(segmented(listOf("Auto", "Light", "Dark"), prefs.themeMode) { i ->
            prefs.themeMode = i
            host.onThemeOrProfileChanged()
        })

        content.addView(label("Look"))
        val cur = if (prefs.profile < 0) Glass.profile else prefs.profile
        content.addView(segmented(listOf("Efficient", "Balanced", "Premium"), cur) { i ->
            prefs.profile = i
            host.onThemeOrProfileChanged()
        })
        val note = TextView(context)
        note.text = "Efficient is lightest on battery and memory. Premium has the strongest glass."
        note.setTextColor(Glass.textA(130))
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        note.setPadding(dp(2), dp(6), 0, 0)
        content.addView(note)

        content.addView(label("Glass transparency"))
        content.addView(slider(prefs.glassTransparency, null) { v ->
            prefs.glassTransparency = v
            Glass.transparency = v
            Glass.version++
            host.onGlassLive()
        })
        content.addView(label("Blur strength"))
        content.addView(slider(prefs.blurStrength, { host.onBlurRegenerate() }) { v ->
            prefs.blurStrength = v
            Glass.blurStrength = v
        })
        content.addView(label("Corner roundness"))
        content.addView(slider(prefs.cornerScale, null) { v ->
            prefs.cornerScale = v
            Glass.corner = v
            Glass.version++
            host.onGlassLive()
        })

        hint.setTextColor(Glass.textA(170))
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        hint.setPadding(dp(2), dp(16), 0, dp(6))
        content.addView(hint)

        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(chip("Photo") { host.onPickPhoto() })
        Wallpapers.NAMES.forEachIndexed { i, n -> row.addView(chip(n) { host.onBuiltinWallpaper(i) }) }
        row.addView(chip("System") { host.onSystemWallpaper() })
        val hs = HorizontalScrollView(context)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(row)
        content.addView(hs)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val tv = TextView(context)
        tv.text = text
        tv.setTextColor(Glass.text)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        tv.setPadding(dp(18), dp(10), dp(18), dp(10))
        val bg = GradientDrawable()
        bg.setColor(Glass.fill)
        bg.cornerRadius = dp(16).toFloat()
        tv.background = bg
        tv.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = dp(8)
        tv.layoutParams = lp
        return tv
    }

    private fun segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        val bg = GradientDrawable()
        bg.setColor(Glass.fill)
        bg.cornerRadius = dp(14).toFloat()
        row.background = bg
        row.setPadding(dp(3), dp(3), dp(3), dp(3))
        val views = ArrayList<TextView>()
        var sel = selected
        val refresh = {
            for (j in views.indices) {
                val v = views[j]
                if (j == sel) {
                    val sb = GradientDrawable()
                    sb.setColor(if (Glass.dark) Color.argb(80, 255, 255, 255) else Color.argb(90, 255, 255, 255))
                    sb.cornerRadius = dp(11).toFloat()
                    sb.setStroke(dp(1), Glass.line)
                    v.background = sb
                } else {
                    v.background = null
                }
                v.setTextColor(if (j == sel) Glass.text else Glass.textA(170))
            }
        }
        options.forEachIndexed { i, o ->
            val tv = TextView(context)
            tv.text = o
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            tv.setPadding(0, dp(10), 0, dp(10))
            tv.setOnClickListener {
                if (sel != i) {
                    sel = i
                    refresh()
                    onSelect(i)
                }
            }
            views.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        refresh()
        return row
    }

    private fun slider(value: Int, onStop: (() -> Unit)?, onChange: (Int) -> Unit): SeekBar {
        val bar = SeekBar(context)
        bar.max = 100
        bar.progress = value
        val accent = ColorStateList.valueOf(Color.rgb(90, 160, 255))
        bar.progressTintList = accent
        bar.thumbTintList = accent
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}

            override fun onStopTrackingTouch(sb: SeekBar?) {
                onStop?.invoke()
            }
        })
        return bar
    }
}
