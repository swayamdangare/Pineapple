package com.glasslauncher.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import java.util.concurrent.Executors
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Rect
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream
import android.app.AlertDialog
import android.app.KeyguardManager
import android.util.TypedValue
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity(), RootLayout.Gesture, RootLayout.DragHost {

    companion object {
        const val MAX_DOCK = 5
        const val SRC_HOME = 0
        const val SRC_DOCK = 1
        const val SRC_DRAWER = 2
        const val REQ_WALLPAPER = 41
        const val REQ_AUTH = 42
    }

    private class DragState(val entry: AppEntry, val source: Int)

    private lateinit var launcherApps: LauncherApps
    private lateinit var store: LayoutStore
    private lateinit var root: RootLayout
    private lateinit var scroller: PageScroller
    private lateinit var dots: DotsView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: DrawerView
    private lateinit var prefs: PrefsStore
    private lateinit var dragLayer: FrameLayout

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var apps: List<AppEntry> = emptyList()
    private var appMap: Map<String, AppEntry> = emptyMap()
    private var data = LayoutData()
    private var layoutLoaded = false

    private var topInset = 0
    private var bottomInset = 0
    private var leftInset = 0
    private var rightInset = 0
    private var currentPage = 0
    private var drawerOpen = false
    private var dragBase = 0f

    // Grid metrics of the last Home build (used to map touches to cells).
    private var mCols = 4
    private var mRows = 6
    private var mCw = 1
    private var mCh = 1
    private var mPadL = 0
    private var mPadT = 0
    private var mW = 1

    // Long-press and drag state.
    private var armedDrag: DragState? = null
    private var armedView: View? = null
    private lateinit var menuLayer: FrameLayout
    private lateinit var sheet: AppearanceSheet
    private var menuCard: View? = null
    private var menuScrim: View? = null
    private var menuAnchor: View? = null
    private var authCallback: (() -> Unit)? = null
    private var dragInDrawer = false
    private var removeZone: TextView? = null
    private var overRemove = false
    private var homeHoldPending = false
    private val homeHold = Runnable {
        homeHoldPending = false
        if (drag != null && dragInDrawer) {
            drawer.dragAbort()
            dragInDrawer = false
            enterHomeDrag()
        }
    }
    private var drag: DragState? = null
    private var ghost: ImageView? = null
    private var highlight: View? = null
    private var hoverPage = 0
    private var hoverCell = 0
    private var dockHover = false
    private var edgeDir = 0

    private val edgeFlip = object : Runnable {
        override fun run() {
            if (edgeDir == 0 || drag == null) return
            val target = (currentPage + edgeDir).coerceIn(0, max(0, scroller.pageCount - 1))
            if (target != currentPage) {
                currentPage = target
                scroller.smoothScrollTo(target * mW, 0)
            }
            ui.postDelayed(this, 700)
        }
    }

    // Event-driven: fires only when apps are installed, removed or updated.
    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
            reload()
            if (packageName != null) ui.postDelayed({ purge(packageName) }, 3000)
        }
        override fun onPackageAdded(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackageChanged(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { reload() }
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { reload() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    // ---------- Device and grid helpers ----------

    private fun isTablet(): Boolean = resources.configuration.smallestScreenWidthDp >= 600
    private fun isLandscape(): Boolean = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private fun dockVertical(): Boolean = isLandscape() && !isTablet()

    // Cells per page are fixed; only their arrangement changes with orientation.
    private fun portraitCols(): Int = if (isTablet()) 5 else 4
    private fun portraitRows(): Int = 6
    private fun capacity(): Int = portraitCols() * portraitRows()
    private fun gridCols(): Int = if (isLandscape()) portraitRows() else portraitCols()
    private fun gridRows(): Int = if (isLandscape()) portraitCols() else portraitRows()

    private fun colsFor(widthPx: Int): Int {
        val wDp = widthPx / resources.displayMetrics.density
        return (wDp / 92f).toInt().coerceIn(4, 8)
    }

    // ---------- Setup ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launcherApps = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        store = LayoutStore(this)
        prefs = PrefsStore(this)
        Glass.configure(this, prefs)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        root = RootLayout(this)
        root.gesture = this
        root.dragHost = this

        scroller = PageScroller(this)
        scroller.onSettled = { currentPage = it }
        scroller.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, oR, ob ->
            if (r - l != oR - ol || b - t != ob - ot) scroller.post { rebuildHome() }
        }
        root.addView(
            scroller,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        dots = DotsView(this)
        scroller.onPosition = { dots.position = it }
        root.addView(
            dots,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
        )

        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GlassDrawable(this, 28f)
            elevation = dp(8).toFloat()
        }
        root.addView(
            dock,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
        )

        drawer = DrawerView(this, prefs, object : DrawerView.Host {
            override fun launch(e: AppEntry) {
                this@MainActivity.launch(e)
                closeDrawer()
            }
            override fun longPress(view: View, e: AppEntry, items: List<Pair<String, () -> Unit>>) {
                armLongPress(view, e, SRC_DRAWER, items)
            }
            override fun addToHome(e: AppEntry) {
                this@MainActivity.addToHome(e)
            }
            override fun addToDock(e: AppEntry) {
                this@MainActivity.addToDock(e)
            }
            override fun appInfo(e: AppEntry) {
                this@MainActivity.appInfo(e)
            }
            override fun showMenu(anchor: View, items: List<Pair<String, () -> Unit>>) {
                this@MainActivity.showMenu(anchor, items)
            }
            override fun uninstall(e: AppEntry) {
                this@MainActivity.uninstall(e)
            }
            override fun hideApp(e: AppEntry) {
                this@MainActivity.hideApp(e)
            }
            override fun requestAuth(onSuccess: () -> Unit) {
                this@MainActivity.requestAuth(onSuccess)
            }
            override fun prompt(title: String, initial: String, onOk: (String) -> Unit) {
                promptText(title, initial, onOk)
            }
            override fun toast(msg: String) {
                this@MainActivity.toast(msg)
            }
        })
        root.addView(
            drawer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        sheet = AppearanceSheet(this, prefs, object : AppearanceSheet.Host {
            override fun onThemeOrProfileChanged() {
                recreate()
            }
            override fun onGlassLive() {
                onGlassChanged()
            }
            override fun onBlurRegenerate() {
                applyWallpaper()
            }
            override fun onPickPhoto() {
                pickWallpaper()
            }
            override fun onBuiltinWallpaper(style: Int) {
                useBuiltinWallpaper(style)
            }
            override fun onSystemWallpaper() {
                useSystemWallpaper()
            }
        })
        root.addView(
            sheet,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        dragLayer = FrameLayout(this)
        root.addView(
            dragLayer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        menuLayer = FrameLayout(this)
        root.addView(
            menuLayer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        updateDrawerColumns()

        root.setOnApplyWindowInsetsListener { _, insets ->
            var t = max(insets.stableInsetTop, statusBarHeight())
            var b = insets.stableInsetBottom
            var l = insets.stableInsetLeft
            var r = insets.stableInsetRight
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = insets.displayCutout
                if (cut != null) {
                    t = max(t, cut.safeInsetTop)
                    b = max(b, cut.safeInsetBottom)
                    l = max(l, cut.safeInsetLeft)
                    r = max(r, cut.safeInsetRight)
                }
            }
            if (t != topInset || b != bottomInset || l != leftInset || r != rightInset) {
                topInset = t
                bottomInset = b
                leftInset = l
                rightInset = r
                applyChrome()
                scroller.post { rebuildHome() }
            }
            insets
        }

        setContentView(root)
        applyChrome()
        launcherApps.registerCallback(callback)
        applyWallpaper()
        reload()
    }

    // Positions the Dock and page dots for the current orientation and insets.
    private fun applyChrome() {
        val vertical = dockVertical()
        val dlp = dock.layoutParams as FrameLayout.LayoutParams
        if (vertical) {
            // Phones in landscape: Dock on the right edge.
            dock.orientation = LinearLayout.VERTICAL
            dlp.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            dlp.bottomMargin = 0
            dlp.rightMargin = rightInset + dp(16)
            dock.minimumWidth = dp(72)
            dock.minimumHeight = dp(96)
        } else {
            dock.orientation = LinearLayout.HORIZONTAL
            dlp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            dlp.bottomMargin = bottomInset + dp(16)
            dlp.rightMargin = 0
            dock.minimumWidth = dp(96)
            dock.minimumHeight = dp(72)
        }
        dock.layoutParams = dlp

        val tlp = dots.layoutParams as FrameLayout.LayoutParams
        tlp.bottomMargin = if (vertical) bottomInset + dp(10) else bottomInset + dp(16 + 72 + 8)
        dots.layoutParams = tlp

        drawer.setInsets(topInset, bottomInset, leftInset, rightInset)
        sheet.setInsets(topInset, bottomInset, leftInset, rightInset)
    }

    private fun updateDrawerColumns() {
        drawer.updateColumns()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateDrawerColumns()
        applyChrome()
        buildDock()
        scroller.post { rebuildHome() }
        applyWallpaper()
    }

    // ---------- Data ----------

    // Icons are drawn once into hardware bitmaps: cheap to draw, light on app memory.
    private fun renderIcon(d: Drawable): Drawable {
        val s = dp(60)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, s, s)
        d.draw(c)
        val hw: Bitmap? = try {
            bmp.copy(Bitmap.Config.HARDWARE, false)
        } catch (e: Exception) {
            null
        }
        return if (hw != null) {
            bmp.recycle()
            BitmapDrawable(resources, hw)
        } else {
            BitmapDrawable(resources, bmp)
        }
    }

    private fun reload() {
        worker.execute {
            val list: List<AppEntry> = try {
                launcherApps.getActivityList(null, Process.myUserHandle())
                    .filter { it.componentName.packageName != packageName }
                    .map { AppEntry(it.label.toString(), renderIcon(it.getBadgedIcon(0)), it.componentName, it.user, it.firstInstallTime, it.applicationInfo.category) }
                    .sortedBy { it.label.lowercase() }
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (list.isEmpty() && apps.isNotEmpty()) return@runOnUiThread
                apps = list
                appMap = list.associateBy { it.key }
                if (!layoutLoaded && list.isNotEmpty()) {
                    val saved = store.load(capacity())
                    if (saved != null) {
                        data = saved
                    } else {
                        data = defaultLayout()
                    }
                    normalizeLayout()
                    store.save(data)
                    layoutLoaded = true
                }
                drawer.setApps(apps)
                rebuildHome()
                buildDock()
            }
        }
    }

    private fun defaultLayout(): LayoutData {
        val l = LayoutData()
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (p in probes) {
            val pkg: String? = try {
                packageManager.resolveActivity(p, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            } catch (e: Exception) {
                null
            }
            if (pkg == null) continue
            val e = apps.firstOrNull { it.component.packageName == pkg } ?: continue
            if (e.key !in l.dock) l.dock.add(e.key)
        }
        for (e in apps) {
            if (l.dock.size >= 4) break
            if (e.key !in l.dock) l.dock.add(e.key)
        }
        var cell = 0
        for (e in apps) {
            if (cell >= 20) break
            if (e.key in l.dock) continue
            l.home.add(HomeItem(e.key, 0, cell))
            cell++
        }
        return l
    }

    // Repairs a saved layout: duplicates, bad cells, collisions, empty pages.
    private fun normalizeLayout() {
        val cap = capacity()
        val seen = HashSet<String>()
        val used = HashSet<Int>()
        val clean = ArrayList<HomeItem>()
        val loose = ArrayList<HomeItem>()
        for (item in data.home) {
            if (!seen.add(item.key)) continue
            val id = item.page * cap + item.cell
            if (item.page < 0 || item.cell < 0 || item.cell >= cap || !used.add(id)) {
                loose.add(item)
            } else {
                clean.add(item)
            }
        }
        for (item in loose) {
            val id = findFree(0, used)
            used.add(id)
            item.page = id / cap
            item.cell = id % cap
            clean.add(item)
        }
        data.home.clear()
        data.home.addAll(clean)
        val dseen = HashSet<String>()
        data.dock.retainAll { dseen.add(it) }
        compactPages()
    }

    private fun usedSlots(except: HomeItem?): HashSet<Int> {
        val cap = capacity()
        val s = HashSet<Int>()
        for (item in data.home) {
            if (item !== except) s.add(item.page * cap + item.cell)
        }
        return s
    }

    private fun findFree(from: Int, used: Set<Int>): Int {
        var i = max(0, from)
        while (used.contains(i)) i++
        return i
    }

    // Renumbers pages so there are no empty pages in between.
    private fun compactPages() {
        val pages = data.home.map { it.page }.distinct().sorted()
        val map = HashMap<Int, Int>()
        pages.forEachIndexed { i, p -> map[p] = i }
        for (item in data.home) item.page = map[item.page] ?: 0
    }

    // Remove saved icons of an app that is really gone (not just being updated).
    private fun purge(pkg: String) {
        try {
            if (launcherApps.getActivityList(pkg, Process.myUserHandle()).isNotEmpty()) return
        } catch (e: Exception) {
            return
        }
        val prefix = "$pkg/"
        val a = data.home.removeAll { it.key.startsWith(prefix) }
        val b = data.dock.removeAll { it.startsWith(prefix) }
        if (a || b) {
            compactPages()
            store.save(data)
            rebuildHome()
            buildDock()
        }
    }

    // ---------- Home ----------

    private fun rebuildHome() {
        val w = scroller.width
        val h = scroller.height
        if (w <= 0 || h <= 0) return

        val vertical = dockVertical()
        val padTop = topInset + dp(if (vertical) 12 else 24)
        val padBottom = bottomInset + dp(if (vertical) 32 else 124)
        val padLeft = leftInset + dp(12)
        val padRight = rightInset + dp(12) + (if (vertical) dp(96) else 0)
        val cols = gridCols()
        val rows = gridRows()
        val cw = max(1, (w - padLeft - padRight) / cols)
        val ch = max(1, (h - padTop - padBottom) / rows)
        mCols = cols
        mRows = rows
        mCw = cw
        mCh = ch
        mPadL = padLeft
        mPadT = padTop
        mW = w
        val iconDp = ((ch / resources.displayMetrics.density) - 26f).toInt().coerceIn(30, 56)

        val dragKey = drag?.entry?.key
        val maxPage = data.home.maxOfOrNull { it.page } ?: 0
        // While dragging, one extra empty page lets you start a new page.
        val pageCount = maxPage + 1 + (if (drag != null) 1 else 0)

        scroller.content.removeAllViews()
        for (p in 0 until pageCount) {
            val grid = IconGrid(this, cols, rows)
            grid.setPadding(padLeft, padTop, padRight, padBottom)
            grid.setOnLongClickListener {
                showHomeMenu()
                true
            }
            for (item in data.home) {
                if (item.page != p || item.key == dragKey) continue
                val e = appMap[item.key] ?: continue
                grid.addCell(homeCell(e, iconDp), item.cell)
            }
            scroller.content.addView(grid, LinearLayout.LayoutParams(w, h))
        }
        scroller.pageCount = pageCount
        currentPage = currentPage.coerceIn(0, pageCount - 1)
        dots.count = pageCount

        scroller.content.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(
                v: View?, l: Int, t: Int, r: Int, b: Int,
                ol: Int, ot: Int, oR: Int, ob: Int
            ) {
                v?.removeOnLayoutChangeListener(this)
                scroller.scrollTo(currentPage * w, 0)
                dots.position = currentPage.toFloat()
            }
        })
    }

    private fun homeCell(e: AppEntry, iconDp: Int): View {
        val c = buildCell(this, iconDp)
        bindCell(c, e)
        c.setOnClickListener { launch(e) }
        c.setOnLongClickListener {
            armLongPress(
                c, e, SRC_HOME,
                listOf(
                    "Remove from Home Screen" to { removeFromHome(e) },
                    "App info" to { appInfo(e) }
                )
            )
            true
        }
        return c
    }

    private fun buildDock() {
        dock.removeAllViews()
        val vertical = dockVertical()
        val dragKey = drag?.entry?.key
        val list = data.dock.filter { it != dragKey }.mapNotNull { appMap[it] }
        for (e in list) {
            val iv = ImageView(this)
            iv.setImageDrawable(e.newIcon())
            val lp = LinearLayout.LayoutParams(dp(52), dp(52))
            if (vertical) lp.setMargins(0, dp(6), 0, dp(6)) else lp.setMargins(dp(6), 0, dp(6), 0)
            iv.layoutParams = lp
            iv.setOnClickListener { launch(e) }
            iv.setOnLongClickListener {
                armLongPress(
                    iv, e, SRC_DOCK,
                    listOf(
                        "Remove from Dock" to { removeFromDock(e) },
                        "App info" to { appInfo(e) }
                    )
                )
                true
            }
            dock.addView(iv)
        }
    }

    // ---------- Actions ----------

    // ---------- Floating menu ----------

    private fun showMenu(anchor: View, items: List<Pair<String, () -> Unit>>) {
        dismissMenu(false)
        val scrim = View(this)
        scrim.setOnClickListener { dismissMenu(true) }
        menuLayer.addView(
            scrim,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(6), 0, dp(6))
        items.forEachIndexed { i, item ->
            val tv = TextView(this)
            tv.text = item.first
            tv.setTextColor(Glass.text)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            tv.gravity = Gravity.CENTER_VERTICAL
            tv.setPadding(dp(18), 0, dp(18), 0)
            tv.setOnClickListener {
                dismissMenu(true)
                item.second()
            }
            list.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
            if (i < items.size - 1) {
                val line = View(this)
                line.setBackgroundColor(Glass.line)
                val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                llp.setMargins(dp(14), 0, dp(14), 0)
                list.addView(line, llp)
            }
        }
        val w = dp(230)
        list.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxH = root.height - topInset - bottomInset - dp(40)
        val ch = min(list.measuredHeight, maxH)

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(
            list,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        val card = FrameLayout(this)
        card.background = GlassDrawable(card, 18f, null, true, 1.15f)
        card.elevation = dp(12).toFloat()
        card.clipToOutline = true
        card.addView(
            scroll,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        val cx = loc[0] + anchor.width / 2
        val margin = dp(12)
        val x = (cx - w / 2).coerceIn(margin, max(margin, root.width - w - margin))
        val below = loc[1] + anchor.height + dp(8)
        val showBelow = below + ch <= root.height - bottomInset - margin
        val y = if (showBelow) below else max(topInset + margin, loc[1] - ch - dp(8))
        card.translationX = x.toFloat()
        card.translationY = y.toFloat()
        card.pivotX = (cx - x).toFloat()
        card.pivotY = if (showBelow) 0f else ch.toFloat()
        card.scaleX = 0.7f
        card.scaleY = 0.7f
        card.alpha = 0f
        menuLayer.addView(card, FrameLayout.LayoutParams(w, ch))
        card.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(170)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .start()
        menuCard = card
        menuScrim = scrim
        menuAnchor = anchor
    }

    private fun dismissMenu(animate: Boolean) {
        val card = menuCard ?: return
        val scrim = menuScrim
        val anchor = menuAnchor
        menuCard = null
        menuScrim = null
        menuAnchor = null
        if (anchor != null) {
            anchor.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            if (anchor.parent === dragLayer) dragLayer.removeView(anchor)
        }
        if (scrim != null) menuLayer.removeView(scrim)
        if (animate) {
            card.animate()
                .alpha(0f)
                .scaleX(0.9f)
                .scaleY(0.9f)
                .setDuration(110)
                .withEndAction { menuLayer.removeView(card) }
                .start()
        } else {
            card.animate().cancel()
            menuLayer.removeView(card)
        }
    }

    // Opens the system screen-lock check (PIN, pattern, password or fingerprint).
    private fun requestAuth(onSuccess: () -> Unit) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) {
            toast("Set a screen lock in Android Settings to open Hidden apps")
            return
        }
        val i = km.createConfirmDeviceCredentialIntent("Hidden apps", "Confirm your screen lock to continue")
        if (i == null) {
            toast("Can't verify right now")
            return
        }
        authCallback = onSuccess
        try {
            startActivityForResult(i, REQ_AUTH)
        } catch (e: Exception) {
            authCallback = null
            toast("Can't verify right now")
        }
    }

    private fun promptText(title: String, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this)
        input.setSingleLine(true)
        input.setText(initial)
        input.setSelection(input.text.length)
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
    }

    private fun uninstall(e: AppEntry) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + e.component.packageName)))
        } catch (ex: Exception) {
            toast("Can't uninstall this app")
        }
    }

    // Hiding removes the app from Home and Dock too.
    private fun hideApp(e: AppEntry) {
        data.home.removeAll { it.key == e.key }
        data.dock.remove(e.key)
        compactPages()
        store.save(data)
        rebuildHome()
        buildDock()
    }

    private fun addToHome(e: AppEntry) {
        if (data.home.any { it.key == e.key }) {
            toast("Already on Home Screen")
            return
        }
        val cap = capacity()
        val id = findFree(0, usedSlots(null))
        data.dock.remove(e.key)
        data.home.add(HomeItem(e.key, id / cap, id % cap))
        compactPages()
        store.save(data)
        currentPage = data.home.firstOrNull { it.key == e.key }?.page ?: 0
        rebuildHome()
        buildDock()
        toast("Added to Home Screen")
        closeDrawer()
    }

    private fun addToDock(e: AppEntry) {
        if (data.dock.contains(e.key)) {
            toast("Already in Dock")
            return
        }
        if (data.dock.size >= MAX_DOCK) {
            toast("Dock is full. Remove an app first.")
            return
        }
        data.home.removeAll { it.key == e.key }
        data.dock.add(e.key)
        compactPages()
        store.save(data)
        rebuildHome()
        buildDock()
        toast("Added to Dock")
    }

    private fun removeFromHome(e: AppEntry) {
        data.home.removeAll { it.key == e.key }
        compactPages()
        store.save(data)
        rebuildHome()
    }

    private fun removeFromDock(e: AppEntry) {
        data.dock.remove(e.key)
        store.save(data)
        buildDock()
    }

    private fun appInfo(e: AppEntry) {
        try {
            launcherApps.startAppDetailsActivity(e.component, e.user, null, null)
        } catch (ex: Exception) {
            toast("Can't open app info")
        }
    }

    private fun launch(e: AppEntry) {
        prefs.recordLaunch(e.key)
        try {
            launcherApps.startMainActivity(e.component, e.user, null, null)
        } catch (ex: Exception) {
            toast("Can't open " + e.label)
        }
    }

    // ---------- Long-press, menu and drag ----------

    // Long-press lifts the icon and opens the menu at once.
    // Moving the finger instead of lifting it turns this into a drag.
    private fun armLongPress(view: View, entry: AppEntry, source: Int, items: List<Pair<String, () -> Unit>>) {
        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        view.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
        armedDrag = DragState(entry, source)
        armedView = view
        root.arm()
        showMenu(view, items)
    }

    override fun onArmedEnd(released: Boolean) {
        armedDrag = null
        armedView = null
        if (!released) dismissMenu(true)
    }

    override fun onDragStart(x: Float, y: Float): Boolean {
        val st = armedDrag ?: return false
        armedDrag = null
        armedView = null
        dismissMenu(false)
        hideKeyboard()
        drag = st

        val size = dp(60)
        val g = ImageView(this)
        g.setImageDrawable(st.entry.newIcon())
        g.alpha = 0.92f
        g.scaleX = 0.8f
        g.scaleY = 0.8f
        g.layoutParams = FrameLayout.LayoutParams(size, size)
        dragLayer.addView(g)
        g.animate().scaleX(1.1f).scaleY(1.1f).setDuration(140).start()
        ghost = g

        edgeDir = 0
        dockHover = false
        overRemove = false
        if (st.source == SRC_DRAWER && drawerOpen) {
            // Stay in the drawer: drop on a category tile, or on Home / Dock / Remove.
            dragInDrawer = true
            drawer.dragBegin(st.entry)
        } else {
            dragInDrawer = false
            enterHomeDrag()
        }
        return true
    }

    // Home-screen side of a drag: cell highlight, Dock target, Remove zone.
    private fun enterHomeDrag() {
        val st = drag ?: return
        if (drawerOpen) closeDrawer()

        val hl = View(this)
        hl.background = GradientDrawable().apply {
            setColor(0x33FFFFFF)
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), 0x55FFFFFF)
        }
        hl.layoutParams = FrameLayout.LayoutParams(max(1, mCw - dp(12)), max(1, mCh - dp(12)))
        hl.visibility = View.INVISIBLE
        dragLayer.addView(hl, 0)
        highlight = hl

        if (st.source != SRC_DRAWER) {
            val rz = TextView(this)
            rz.text = "Remove from Home Screen"
            rz.setTextColor(Color.WHITE)
            rz.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            rz.gravity = Gravity.CENTER
            rz.setPadding(dp(20), 0, dp(20), 0)
            rz.background = GradientDrawable().apply {
                setColor(Color.argb(200, 224, 67, 75))
                cornerRadius = dp(22).toFloat()
            }
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(44),
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            )
            lp.topMargin = topInset + dp(12)
            rz.alpha = 0f
            rz.translationY = -dp(40).toFloat()
            dragLayer.addView(rz, lp)
            rz.animate().alpha(1f).translationY(0f).setDuration(200).start()
            removeZone = rz
        }
        rebuildHome()
        buildDock()
    }

    private fun removeGhost() {
        val g = ghost
        ghost = null
        if (g != null) {
            g.animate()
                .alpha(0f)
                .scaleX(0.7f)
                .scaleY(0.7f)
                .setDuration(140)
                .withEndAction { dragLayer.removeView(g) }
                .start()
        }
    }

    private fun isOverDock(x: Float, y: Float): Boolean {
        val loc = IntArray(2)
        dock.getLocationInWindow(loc)
        val m = dp(24)
        return x >= loc[0] - m && x <= loc[0] + dock.width + m &&
            y >= loc[1] - m && y <= loc[1] + dock.height + m
    }

    private fun dockIndexAt(x: Float, y: Float): Int {
        val vertical = dockVertical()
        val loc = IntArray(2)
        var idx = 0
        for (i in 0 until dock.childCount) {
            val c = dock.getChildAt(i)
            c.getLocationInWindow(loc)
            val center = if (vertical) loc[1] + c.height / 2f else loc[0] + c.width / 2f
            val pos = if (vertical) y else x
            if (pos > center) idx++
        }
        return idx
    }

    override fun onDragMove(x: Float, y: Float) {
        val g = ghost ?: return
        val half = g.layoutParams.width / 2f
        g.translationX = x - half
        g.translationY = y - half

        if (dragInDrawer) {
            val t = drawer.dragHover(x, y)
            if (t == 1) {
                // Hold over "Home Screen" to place the app on a page.
                if (!homeHoldPending) {
                    homeHoldPending = true
                    ui.postDelayed(homeHold, 450)
                }
            } else if (homeHoldPending) {
                homeHoldPending = false
                ui.removeCallbacks(homeHold)
            }
            return
        }

        val hl = highlight ?: return
        val rz = removeZone
        val overRz = rz != null && y < topInset + dp(72)
        if (overRz != overRemove) {
            overRemove = overRz
            val rs = if (overRz) 1.1f else 1f
            rz?.animate()?.scaleX(rs)?.scaleY(rs)?.setDuration(120)?.start()
        }

        val over = !overRz && isOverDock(x, y)
        if (over != dockHover) {
            dockHover = over
            val s = if (over) 1.08f else 1f
            dock.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
        if (over || overRz) {
            hl.visibility = View.INVISIBLE
        } else {
            val xAbs = scroller.scrollX + x
            val page = (xAbs / mW).toInt().coerceIn(0, max(0, scroller.pageCount - 1))
            val xIn = xAbs - page * mW
            val col = ((xIn - mPadL) / mCw).toInt().coerceIn(0, mCols - 1)
            val row = ((y - mPadT) / mCh).toInt().coerceIn(0, mRows - 1)
            hoverPage = page
            hoverCell = row * mCols + col
            hl.translationX = (page * mW - scroller.scrollX + mPadL + col * mCw + dp(6)).toFloat()
            hl.translationY = (mPadT + row * mCh + dp(6)).toFloat()
            hl.visibility = View.VISIBLE
        }

        // Hold near a side edge to flip pages.
        val m = dp(36)
        val dir = if (x < m) -1 else if (x > root.width - m) 1 else 0
        if (dir != edgeDir) {
            edgeDir = dir
            ui.removeCallbacks(edgeFlip)
            if (dir != 0) ui.postDelayed(edgeFlip, 450)
        }
    }

    override fun onDragEnd(x: Float, y: Float, cancelled: Boolean) {
        val st = drag ?: return
        ui.removeCallbacks(edgeFlip)
        ui.removeCallbacks(homeHold)
        homeHoldPending = false
        edgeDir = 0

        if (dragInDrawer) {
            dragInDrawer = false
            drag = null
            removeGhost()
            drawer.dragEnd(x, y, cancelled)
            return
        }

        val wasRemove = overRemove
        val overDock = isOverDock(x, y) && !wasRemove
        val dockIdx = dockIndexAt(x, y)
        val page = hoverPage
        val cell = hoverCell

        removeGhost()
        highlight?.let { dragLayer.removeView(it) }
        highlight = null
        val rz = removeZone
        if (rz != null) {
            rz.animate().alpha(0f).setDuration(140).withEndAction { dragLayer.removeView(rz) }.start()
        }
        removeZone = null
        overRemove = false
        dock.animate().cancel()
        dock.scaleX = 1f
        dock.scaleY = 1f
        dockHover = false
        drag = null

        if (!cancelled) {
            if (wasRemove) {
                data.home.removeAll { it.key == st.entry.key }
                data.dock.remove(st.entry.key)
                toast("Removed from Home Screen")
            } else if (overDock) {
                dropOnDock(st.entry, dockIdx)
            } else {
                dropOnHome(st.entry, page, cell)
            }
            compactPages()
            data.home.firstOrNull { it.key == st.entry.key }?.let { currentPage = it.page }
            store.save(data)
        }
        rebuildHome()
        buildDock()
    }

    private fun dropOnDock(e: AppEntry, idx: Int) {
        val wasInDock = data.dock.contains(e.key)
        if (!wasInDock && data.dock.size >= MAX_DOCK) {
            toast("Dock is full. Remove an app first.")
            return
        }
        data.home.removeAll { it.key == e.key }
        data.dock.remove(e.key)
        data.dock.add(idx.coerceIn(0, data.dock.size), e.key)
    }

    private fun dropOnHome(e: AppEntry, page: Int, cell: Int) {
        val cap = capacity()
        val existing = data.home.firstOrNull { it.key == e.key }
        data.dock.remove(e.key)
        if (existing != null) data.home.remove(existing)
        val occupant = data.home.firstOrNull { it.page == page && it.cell == cell }
        if (occupant != null) {
            if (existing != null) {
                // Swap places.
                occupant.page = existing.page
                occupant.cell = existing.cell
            } else {
                // Push the occupant to the next free cell.
                val used = usedSlots(occupant)
                used.add(page * cap + cell)
                val free = findFree(page * cap + cell + 1, used)
                occupant.page = free / cap
                occupant.cell = free % cap
            }
        }
        data.home.add(HomeItem(e.key, page, cell))
    }

    // ---------- Drawer ----------

    private fun hideKeyboard() {
        drawer.hideKeyboard()
    }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    // Home content scales back and dims as the drawer rises.
    private fun applyProgress() {
        val h = max(1, root.height).toFloat()
        val p = (1f - drawer.translationY / h).coerceIn(0f, 1f)
        val s = 1f - 0.06f * p
        scroller.scaleX = s
        scroller.scaleY = s
        scroller.alpha = 1f - 0.5f * p
        dock.alpha = 1f - p
        dots.alpha = 1f - p
    }

    private fun openDrawer() {
        drawerOpen = true
        if (drawer.visibility != View.VISIBLE) {
            drawer.refresh()
            drawer.translationY = root.height.toFloat()
            drawer.visibility = View.VISIBLE
        }
        drawer.animate()
            .translationY(0f)
            .setDuration(300)
            .setInterpolator(DecelerateInterpolator(1.5f))
            .setUpdateListener { applyProgress() }
            .start()
    }

    private fun closeDrawer() {
        drawerOpen = false
        drawer.reset()
        drawer.animate()
            .translationY(root.height.toFloat())
            .setDuration(250)
            .setInterpolator(DecelerateInterpolator())
            .setUpdateListener { applyProgress() }
            .withEndAction {
                if (!drawerOpen) drawer.visibility = View.GONE
            }
            .start()
    }

    override fun shouldIntercept(dy: Float): Boolean {
        if (sheet.isOpen) return false
        return if (drawerOpen) dy > 0 && !drawer.canScrollUp() else dy < 0
    }

    override fun onDragStart() {
        drawer.animate().cancel()
        hideKeyboard()
        if (drawer.visibility != View.VISIBLE) {
            drawer.refresh()
            drawer.translationY = root.height.toFloat()
            drawer.visibility = View.VISIBLE
        }
        dragBase = drawer.translationY
    }

    override fun onDrag(dy: Float) {
        drawer.translationY = (dragBase + dy).coerceIn(0f, root.height.toFloat())
        applyProgress()
    }

    override fun onRelease(dy: Float, vy: Float) {
        val h = root.height.toFloat()
        val open = when {
            vy < -1000f -> true
            vy > 1000f -> false
            else -> drawer.translationY < h * 0.5f
        }
        if (open) openDrawer() else closeDrawer()
    }

    // ---------- Wallpaper ----------
    // The launcher keeps its own copy, cropped for portrait and landscape,
    // so the wallpaper always fills the screen.

    private fun wallpaperFile(portrait: Boolean): File =
        File(filesDir, if (portrait) "wp_portrait.jpg" else "wp_landscape.jpg")

    private fun applyWallpaper() {
        if (!prefs.customWallpaper) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            Glass.blur = null
            Glass.version++
            onGlassChanged()
            return
        }
        val file = wallpaperFile(!isLandscape())
        worker.execute {
            val bmp: Bitmap? = try {
                val o = BitmapFactory.Options()
                o.inPreferredConfig = Bitmap.Config.RGB_565
                BitmapFactory.decodeFile(file.absolutePath, o)
            } catch (e: Exception) {
                null
            }
            val blurBmp: Bitmap? = try {
                if (bmp != null && Glass.profile != Glass.EFFICIENT) Blur.make(bmp, Glass.blurStrength) else null
            } catch (e: Exception) {
                null
            } catch (e: OutOfMemoryError) {
                null
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (bmp != null) {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
                    window.setBackgroundDrawable(BitmapDrawable(resources, bmp))
                    Glass.blur = blurBmp
                    Glass.version++
                    onGlassChanged()
                } else {
                    prefs.customWallpaper = false
                    applyWallpaper()
                }
            }
        }
    }

    private fun pickWallpaper() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "image/*"
            startActivityForResult(i, REQ_WALLPAPER)
        } catch (e: Exception) {
            toast("No photo picker available")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, result: Intent?) {
        super.onActivityResult(requestCode, resultCode, result)
        if (requestCode == REQ_AUTH) {
            val cb = authCallback
            authCallback = null
            if (resultCode == Activity.RESULT_OK && cb != null) cb()
            return
        }
        val uri = result?.data
        if (requestCode == REQ_WALLPAPER && resultCode == Activity.RESULT_OK && uri != null) {
            importWallpaper(uri)
        }
    }

    private fun importWallpaper(uri: Uri) {
        toast("Setting wallpaper...")
        worker.execute {
            var ok = false
            try {
                val dm = resources.displayMetrics
                val longSide = max(dm.widthPixels, dm.heightPixels)
                val shortSide = min(dm.widthPixels, dm.heightPixels)
                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= longSide && bounds.outHeight / (sample * 2) >= longSide) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options()
                opts.inSampleSize = sample
                opts.inPreferredConfig = Bitmap.Config.RGB_565
                val src: Bitmap? = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (src != null) {
                    saveCrop(src, shortSide, longSide, wallpaperFile(true))
                    saveCrop(src, longSide, shortSide, wallpaperFile(false))
                    src.recycle()
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            } catch (e: OutOfMemoryError) {
                ok = false
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (ok) {
                    prefs.customWallpaper = true
                    applyWallpaper()
                } else {
                    toast("Couldn't use that image")
                }
            }
        }
    }

    // Center-crops the source to exactly tw x th and saves it as JPEG.
    private fun saveCrop(src: Bitmap, tw: Int, th: Int, out: File) {
        val scale = max(tw / src.width.toFloat(), th / src.height.toFloat())
        val cw = (tw / scale).toInt()
        val ch = (th / scale).toInt()
        val left = max(0, (src.width - cw) / 2)
        val top = max(0, (src.height - ch) / 2)
        val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.RGB_565)
        val c = Canvas(bmp)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(
            src,
            Rect(left, top, min(src.width, left + cw), min(src.height, top + ch)),
            Rect(0, 0, tw, th),
            p
        )
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
    }

    private fun onGlassChanged() {
        dock.invalidate()
        drawer.refreshGlass()
        sheet.refreshGlass()
    }

    private fun writeJpeg(bmp: Bitmap, out: File) {
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        bmp.recycle()
    }

    private fun useBuiltinWallpaper(style: Int) {
        toast("Setting wallpaper...")
        worker.execute {
            var ok = false
            try {
                val dm = resources.displayMetrics
                val longSide = max(dm.widthPixels, dm.heightPixels)
                val shortSide = min(dm.widthPixels, dm.heightPixels)
                writeJpeg(Wallpapers.make(style, shortSide, longSide), wallpaperFile(true))
                writeJpeg(Wallpapers.make(style, longSide, shortSide), wallpaperFile(false))
                ok = true
            } catch (e: Exception) {
                ok = false
            } catch (e: OutOfMemoryError) {
                ok = false
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (ok) {
                    prefs.customWallpaper = true
                    applyWallpaper()
                } else {
                    toast("Couldn't create the wallpaper")
                }
            }
        }
    }

    private fun useSystemWallpaper() {
        prefs.customWallpaper = false
        wallpaperFile(true).delete()
        wallpaperFile(false).delete()
        applyWallpaper()
    }

    // Long-press on an empty Home area.
    private fun showHomeMenu() {
        val anchor = View(this)
        anchor.layoutParams = FrameLayout.LayoutParams(1, 1)
        anchor.translationX = root.touchX
        anchor.translationY = root.touchY
        dragLayer.addView(anchor)
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("Appearance" to { sheet.open() })
        items.add("Wallpaper photo" to { pickWallpaper() })
        if (prefs.customWallpaper) items.add("Use system wallpaper" to { useSystemWallpaper() })
        showMenu(anchor, items)
    }

    // ---------- Lifecycle ----------

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer()
        currentPage = 0
        scroller.smoothScrollTo(0, 0)
    }

    // A launcher must not close on Back.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (menuCard != null) {
            dismissMenu(true)
            return
        }
        if (sheet.isOpen) {
            sheet.close()
            return
        }
        if (drawerOpen) {
            if (!drawer.handleBack()) closeDrawer()
        }
    }

    override fun onDestroy() {
        launcherApps.unregisterCallback(callback)
        ui.removeCallbacksAndMessages(null)
        worker.shutdown()
        super.onDestroy()
    }
}
