package com.glasslauncher.app

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.pm.LauncherApps
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Process
import android.os.UserHandle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class AppEntry(
    val label: String,
    val icon: Drawable,
    val component: ComponentName,
    val user: UserHandle
)

class MainActivity : Activity() {

    private lateinit var launcherApps: LauncherApps
    private lateinit var grid: GridView
    private lateinit var dock: LinearLayout
    private val adapter = AppAdapter()
    private val worker = Executors.newSingleThreadExecutor()
    private var apps: List<AppEntry> = emptyList()
    private var topInset = 0
    private var bottomInset = 0

    // Event-driven: fires only when apps are installed, removed or updated.
    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackageAdded(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackageChanged(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { reload() }
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { reload() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launcherApps = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val root = FrameLayout(this)

        grid = GridView(this).apply {
            selector = ColorDrawable(Color.TRANSPARENT)
            verticalSpacing = dp(16)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            clipToPadding = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
            setOnItemLongClickListener { _, _, pos, _ ->
                try {
                    launcherApps.startAppDetailsActivity(apps[pos].component, apps[pos].user, null, null)
                } catch (e: Exception) { }
                true
            }
        }
        updateColumns()
        root.addView(
            grid,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(0x55FFFFFF)
                cornerRadius = dp(30).toFloat()
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        root.addView(
            dock,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
        )

        root.setOnApplyWindowInsetsListener { _, insets ->
            topInset = insets.systemWindowInsetTop
            bottomInset = insets.systemWindowInsetBottom
            applyInsets()
            insets
        }

        setContentView(root)
        applyInsets()
        launcherApps.registerCallback(callback)
        reload()
    }

    private fun applyInsets() {
        grid.setPadding(dp(16), topInset + dp(24), dp(16), bottomInset + dp(120))
        val lp = dock.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = bottomInset + dp(16)
        dock.layoutParams = lp
    }

    private fun updateColumns() {
        val dm = resources.displayMetrics
        val widthDp = dm.widthPixels / dm.density
        grid.numColumns = maxOf(4, (widthDp / 90f).toInt())
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateColumns()
    }

    private fun reload() {
        worker.execute {
            val list: List<AppEntry> = try {
                launcherApps.getActivityList(null, Process.myUserHandle())
                    .filter { it.componentName.packageName != packageName }
                    .map { AppEntry(it.label.toString(), it.getBadgedIcon(0), it.componentName, it.user) }
                    .sortedBy { it.label.lowercase() }
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread {
                if (!isDestroyed) {
                    apps = list
                    adapter.notifyDataSetChanged()
                    buildDock()
                }
            }
        }
    }

    private fun buildDock() {
        dock.removeAllViews()
        for (entry in apps.take(4)) {
            val iv = ImageView(this)
            iv.setImageDrawable(entry.icon.constantState?.newDrawable() ?: entry.icon)
            val lp = LinearLayout.LayoutParams(dp(60), dp(60))
            lp.setMargins(dp(8), 0, dp(8), 0)
            iv.layoutParams = lp
            iv.setOnClickListener { launch(entry) }
            dock.addView(iv)
        }
    }

    private fun launch(entry: AppEntry) {
        try {
            launcherApps.startMainActivity(entry.component, entry.user, null, null)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open " + entry.label, Toast.LENGTH_SHORT).show()
        }
    }

    // A launcher must ignore Back.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { }

    override fun onDestroy() {
        launcherApps.unregisterCallback(callback)
        worker.shutdown()
        super.onDestroy()
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = apps.size
        override fun getItem(position: Int): Any = apps[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cell = (convertView as? LinearLayout) ?: makeCell()
            val e = apps[position]
            (cell.getChildAt(0) as ImageView).setImageDrawable(e.icon)
            (cell.getChildAt(1) as TextView).text = e.label
            return cell
        }

        private fun makeCell(): LinearLayout {
            val cell = LinearLayout(this@MainActivity)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL

            val icon = ImageView(this@MainActivity)
            icon.layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
            cell.addView(icon)

            val label = TextView(this@MainActivity)
            label.setTextColor(Color.WHITE)
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            label.maxLines = 1
            label.ellipsize = TextUtils.TruncateAt.END
            label.gravity = Gravity.CENTER
            label.setShadowLayer(4f, 0f, 1f, 0x66000000)
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6)
            label.layoutParams = lp
            cell.addView(label)
            return cell
        }
    }
}
