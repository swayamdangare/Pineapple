package com.glasslauncher.app

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.UserHandle
import org.json.JSONArray
import org.json.JSONObject

class AppEntry(
    val label: String,
    val icon: Drawable,
    val component: ComponentName,
    val user: UserHandle
) {
    val key: String = component.flattenToString()
    fun newIcon(): Drawable = icon.constantState?.newDrawable()?.mutate() ?: icon
}

// home: ordered app keys that flow across pages. dock: ordered app keys.
class LayoutData {
    val home = ArrayList<String>()
    val dock = ArrayList<String>()
}

class LayoutStore(context: Context) {
    private val prefs = context.getSharedPreferences("layout", Context.MODE_PRIVATE)

    fun load(): LayoutData? {
        val raw = prefs.getString("layout_v1", null) ?: return null
        return try {
            val o = JSONObject(raw)
            val l = LayoutData()
            val h = o.getJSONArray("home")
            for (i in 0 until h.length()) l.home.add(h.getString(i))
            val d = o.getJSONArray("dock")
            for (i in 0 until d.length()) l.dock.add(d.getString(i))
            l
        } catch (e: Exception) {
            null
        }
    }

    fun save(l: LayoutData) {
        val o = JSONObject()
        o.put("v", 1)
        o.put("home", JSONArray(l.home))
        o.put("dock", JSONArray(l.dock))
        prefs.edit().putString("layout_v1", o.toString()).apply()
    }
}
