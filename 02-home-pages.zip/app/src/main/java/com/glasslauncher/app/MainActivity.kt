package com.glasslauncher.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity(), RootLayout.Gesture {

    companion object {
        const val MAX_DOCK = 5
    }

    private lateinit var launcherApps: LauncherApps
    private lateinit var store: LayoutStore
    private lateinit var root: RootLayout
    private lateinit var scroller: PageScroller
    private lateinit var dots: DotsView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var drawerGrid: GridView
    private val drawerAdapter = DrawerAdapter()

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var apps: List<AppEntry> = emptyList()
    private var appMap: Map<String, AppEntry> = emptyMap()
    private var shown: List<AppEntry> = emptyList()
    private var data = LayoutData()
    private var layoutLoaded = false

    private var topInset = 0
    private var bottomInset = 0
    private var leftInset = 0
    private var rightInset = 0
    private var currentPage = 0
    private var perPage = 20
    private var drawerOpen = false
    private var dragBase = 0f

    // Event-driven: fires only when apps are installed, removed or updated.
    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
            reload()
            if (packageName != null) ui.postDelayed({ purge(packageName) }, 3000)
        }
        override fun onPackageAdded(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackageChanged(packageName: String?, user: UserHandle?) { reload() }
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { reload() }
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { reload() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun colsFor(widthPx: Int): Int {
        val wDp = widthPx / resources.displayMetrics.density
        return (wDp / 92f).toInt().coerceIn(4, 8)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launcherApps = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        store = LayoutStore(this)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        root = RootLayout(this)
        root.gesture = this

        // Home pages
        scroller = PageScroller(this)
        scroller.onSettled = { currentPage = it }
        scroller.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, oR, ob ->
            if (r - l != oR - ol || b - t != ob - ot) scroller.post { rebuildHome() }
        }
        root.addView(
            scroller,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // Page dots
        dots = DotsView(this)
        scroller.onPosition = { dots.position = it }
        root.addView(
            dots,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
        )

        // Dock
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                setColor(0x55FFFFFF)
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        root.addView(
            dock,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
        )

        // App drawer
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(242, 16, 16, 24))
            isClickable = true
            visibility = View.GONE
        }
        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Color.argb(153, 255, 255, 255))
            setTextColor(Color.WHITE)
            textSize = 16f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                setColor(0x26FFFFFF)
                cornerRadius = dp(14).toFloat()
            }
            setOnEditorActionListener { _, _, _ ->
                hideKeyboard()
                true
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    applyFilter(s?.toString() ?: "")
                }
            })
        }
        val searchLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        searchLp.bottomMargin = dp(12)
        drawer.addView(search, searchLp)

        drawerGrid = GridView(this).apply {
            selector = ColorDrawable(Color.TRANSPARENT)
            verticalSpacing = dp(14)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            clipToPadding = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            adapter = drawerAdapter
            setOnItemClickListener { _, _, pos, _ ->
                launch(shown[pos])
                closeDrawer()
            }
            setOnItemLongClickListener { _, view, pos, _ ->
                val e = shown[pos]
                showMenu(
                    view,
                    listOf(
                        "Add to Home Screen" to { addToHome(e) },
                        "Add to Dock" to { addToDock(e) },
                        "App info" to { appInfo(e) }
                    )
                )
                true
            }
        }
        drawer.addView(
            drawerGrid,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(
            drawer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        updateDrawerColumns()

        root.setOnApplyWindowInsetsListener { _, insets ->
            var t = insets.stableInsetTop
            var b = insets.stableInsetBottom
            var l = insets.stableInsetLeft
            var r = insets.stableInsetRight
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = insets.displayCutout
                if (cut != null) {
                    t = max(t, cut.safeInsetTop)
                    b = max(b, cut.safeInsetBottom)
                    l = max(l, cut.safeInsetLeft)
                    r = max(r, cut.safeInsetRight)
                }
            }
            if (t != topInset || b != bottomInset || l != leftInset || r != rightInset) {
                topInset = t
                bottomInset = b
                leftInset = l
                rightInset = r
                applyInsets()
                scroller.post { rebuildHome() }
            }
            insets
        }

        setContentView(root)
        applyInsets()
        launcherApps.registerCallback(callback)
        reload()
    }

    private fun applyInsets() {
        val dlp = dock.layoutParams as FrameLayout.LayoutParams
        dlp.bottomMargin = bottomInset + dp(16)
        dock.layoutParams = dlp

        val tlp = dots.layoutParams as FrameLayout.LayoutParams
        tlp.bottomMargin = bottomInset + dp(16 + 72 + 8)
        dots.layoutParams = tlp

        drawer.setPadding(0, topInset + dp(16), 0, 0)
        val slp = search.layoutParams as LinearLayout.LayoutParams
        slp.leftMargin = leftInset + dp(16)
        slp.rightMargin = rightInset + dp(16)
        search.layoutParams = slp
        drawerGrid.setPadding(leftInset + dp(12), dp(8), rightInset + dp(12), bottomInset + dp(24))
    }

    private fun updateDrawerColumns() {
        drawerGrid.numColumns = colsFor(resources.displayMetrics.widthPixels)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateDrawerColumns()
    }

    // ---------- Data ----------

    private fun reload() {
        worker.execute {
            val list: List<AppEntry> = try {
                launcherApps.getActivityList(null, Process.myUserHandle())
                    .filter { it.componentName.packageName != packageName }
                    .map { AppEntry(it.label.toString(), it.getBadgedIcon(0), it.componentName, it.user) }
                    .sortedBy { it.label.lowercase() }
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (list.isEmpty() && apps.isNotEmpty()) return@runOnUiThread
                apps = list
                appMap = list.associateBy { it.key }
                if (!layoutLoaded && list.isNotEmpty()) {
                    val saved = store.load()
                    if (saved != null) {
                        data = saved
                    } else {
                        data = defaultLayout()
                        store.save(data)
                    }
                    val seenHome = HashSet<String>()
                    data.home.retainAll { seenHome.add(it) }
                    val seenDock = HashSet<String>()
                    data.dock.retainAll { seenDock.add(it) }
                    layoutLoaded = true
                }
                applyFilter(search.text.toString())
                rebuildHome()
                buildDock()
            }
        }
    }

    private fun defaultLayout(): LayoutData {
        val l = LayoutData()
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (p in probes) {
            val pkg: String? = try {
                packageManager.resolveActivity(p, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            } catch (e: Exception) {
                null
            }
            if (pkg == null) continue
            val e = apps.firstOrNull { it.component.packageName == pkg } ?: continue
            if (e.key !in l.dock) l.dock.add(e.key)
        }
        for (e in apps) {
            if (l.dock.size >= 4) break
            if (e.key !in l.dock) l.dock.add(e.key)
        }
        for (e in apps) {
            if (l.home.size >= 24) break
            if (e.key !in l.dock) l.home.add(e.key)
        }
        return l
    }

    // Remove saved icons of an app that is really gone (not just being updated).
    private fun purge(pkg: String) {
        try {
            if (launcherApps.getActivityList(pkg, Process.myUserHandle()).isNotEmpty()) return
        } catch (e: Exception) {
            return
        }
        val prefix = "$pkg/"
        val a = data.home.removeAll { it.startsWith(prefix) }
        val b = data.dock.removeAll { it.startsWith(prefix) }
        if (a || b) {
            store.save(data)
            rebuildHome()
            buildDock()
        }
    }

    private fun applyFilter(q: String) {
        val query = q.trim()
        shown = if (query.isEmpty()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
        drawerAdapter.notifyDataSetChanged()
    }

    // ---------- Home ----------

    private fun rebuildHome() {
        val w = scroller.width
        val h = scroller.height
        if (w <= 0 || h <= 0) return

        val padTop = topInset + dp(24)
        val padBottom = bottomInset + dp(124)
        val availH = h - padTop - padBottom
        val cols = colsFor(w - leftInset - rightInset)
        val rows = max(1, availH / dp(96))
        perPage = cols * rows

        val items = data.home.mapNotNull { appMap[it] }
        val pageCount = max(1, ceil(items.size / perPage.toDouble()).toInt())

        scroller.content.removeAllViews()
        for (p in 0 until pageCount) {
            val grid = IconGrid(this, cols, rows)
            grid.setPadding(leftInset + dp(12), padTop, rightInset + dp(12), padBottom)
            val from = p * perPage
            val to = min(items.size, from + perPage)
            for (i in from until to) grid.addView(homeCell(items[i]))
            scroller.content.addView(grid, LinearLayout.LayoutParams(w, h))
        }
        scroller.pageCount = pageCount
        currentPage = currentPage.coerceIn(0, pageCount - 1)
        dots.count = pageCount

        scroller.content.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(
                v: View?, l: Int, t: Int, r: Int, b: Int,
                ol: Int, ot: Int, oR: Int, ob: Int
            ) {
                v?.removeOnLayoutChangeListener(this)
                scroller.scrollTo(currentPage * w, 0)
                dots.position = currentPage.toFloat()
            }
        })
    }

    private fun homeCell(e: AppEntry): View {
        val c = buildCell(this, 56)
        bindCell(c, e)
        c.setOnClickListener { launch(e) }
        c.setOnLongClickListener {
            showMenu(
                c,
                listOf(
                    "Remove from Home Screen" to { removeFromHome(e) },
                    "App info" to { appInfo(e) }
                )
            )
            true
        }
        return c
    }

    private fun buildDock() {
        dock.removeAllViews()
        val list = data.dock.mapNotNull { appMap[it] }
        dock.visibility = if (list.isEmpty()) View.INVISIBLE else View.VISIBLE
        for (e in list) {
            val iv = ImageView(this)
            iv.setImageDrawable(e.newIcon())
            val lp = LinearLayout.LayoutParams(dp(52), dp(52))
            lp.setMargins(dp(6), 0, dp(6), 0)
            iv.layoutParams = lp
            iv.setOnClickListener { launch(e) }
            iv.setOnLongClickListener {
                showMenu(
                    iv,
                    listOf(
                        "Remove from Dock" to { removeFromDock(e) },
                        "App info" to { appInfo(e) }
                    )
                )
                true
            }
            dock.addView(iv)
        }
    }

    // ---------- Actions ----------

    private fun showMenu(anchor: View, items: List<Pair<String, () -> Unit>>) {
        val popup = PopupMenu(this, anchor)
        items.forEachIndexed { i, item -> popup.menu.add(0, i, i, item.first) }
        popup.setOnMenuItemClickListener { m ->
            items[m.itemId].second()
            true
        }
        popup.show()
    }

    private fun addToHome(e: AppEntry) {
        if (data.home.contains(e.key)) {
            toast("Already on Home Screen")
            return
        }
        data.home.add(e.key)
        store.save(data)
        currentPage = (data.home.size - 1) / max(1, perPage)
        rebuildHome()
        toast("Added to Home Screen")
        closeDrawer()
    }

    private fun addToDock(e: AppEntry) {
        if (data.dock.contains(e.key)) {
            toast("Already in Dock")
            return
        }
        if (data.dock.size >= MAX_DOCK) {
            toast("Dock is full. Remove an app first.")
            return
        }
        data.dock.add(e.key)
        store.save(data)
        buildDock()
        toast("Added to Dock")
    }

    private fun removeFromHome(e: AppEntry) {
        data.home.remove(e.key)
        store.save(data)
        rebuildHome()
    }

    private fun removeFromDock(e: AppEntry) {
        data.dock.remove(e.key)
        store.save(data)
        buildDock()
    }

    private fun appInfo(e: AppEntry) {
        try {
            launcherApps.startAppDetailsActivity(e.component, e.user, null, null)
        } catch (ex: Exception) {
            toast("Can't open app info")
        }
    }

    private fun launch(e: AppEntry) {
        try {
            launcherApps.startMainActivity(e.component, e.user, null, null)
        } catch (ex: Exception) {
            toast("Can't open " + e.label)
        }
    }

    // ---------- Drawer ----------

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    private fun openDrawer() {
        drawerOpen = true
        if (drawer.visibility != View.VISIBLE) {
            drawer.translationY = root.height.toFloat()
            drawer.visibility = View.VISIBLE
        }
        drawer.animate()
            .translationY(0f)
            .setDuration(280)
            .setInterpolator(DecelerateInterpolator(1.5f))
            .start()
    }

    private fun closeDrawer() {
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        drawer.animate()
            .translationY(root.height.toFloat())
            .setDuration(240)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                if (!drawerOpen) {
                    drawer.visibility = View.GONE
                    drawerGrid.setSelection(0)
                }
            }
            .start()
    }

    override fun shouldIntercept(dy: Float): Boolean {
        return if (drawerOpen) dy > 0 && !drawerGrid.canScrollVertically(-1) else dy < 0
    }

    override fun onDragStart() {
        drawer.animate().cancel()
        hideKeyboard()
        if (drawer.visibility != View.VISIBLE) {
            drawer.translationY = root.height.toFloat()
            drawer.visibility = View.VISIBLE
        }
        dragBase = drawer.translationY
    }

    override fun onDrag(dy: Float) {
        drawer.translationY = (dragBase + dy).coerceIn(0f, root.height.toFloat())
    }

    override fun onRelease(dy: Float, vy: Float) {
        val h = root.height.toFloat()
        val open = when {
            vy < -1000f -> true
            vy > 1000f -> false
            else -> drawer.translationY < h * 0.5f
        }
        if (open) openDrawer() else closeDrawer()
    }

    // ---------- Lifecycle ----------

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer()
        currentPage = 0
        scroller.smoothScrollTo(0, 0)
    }

    // A launcher must not close on Back.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            search.text.isNotEmpty() -> search.setText("")
            drawerOpen -> closeDrawer()
            else -> { }
        }
    }

    override fun onDestroy() {
        launcherApps.unregisterCallback(callback)
        ui.removeCallbacksAndMessages(null)
        worker.shutdown()
        super.onDestroy()
    }

    private inner class DrawerAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cell = convertView ?: buildCell(this@MainActivity, 56)
            bindCell(cell, shown[position])
            return cell
        }
    }
}
